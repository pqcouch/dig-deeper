# Tools 1–2: Purpose and Context

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 2–3.

---

## 1. Author's Purpose

**The question:** Why did the author write this? What is the overall thrust of the book/section into which this passage fits?

**The principle:** This is "the Swiss army knife from which all the other tools fold out." Every other tool ultimately serves Author's Purpose. Miss the overall purpose, and you haven't really understood the passage.

### What to do

For **NT letters / OT prophets**, ask:
- Who is writing, and to whom?
- What is the situation of author and readers?
- What problems need addressing?
- What are the repeated themes?

For **narrative**, ask:
- What has the author chosen to include, and what to leave out?
- Where does he hit the accelerator (a life in two verses) and where does he slow down (hours in detail)?
- When two accounts overlap (Samuel/Kings vs Chronicles; the four Gospels), why these emphases, not those?

For **everything else** (Ecclesiastes, Leviticus, Song of Songs): follow your nose. What themes dominate? What seem to be the author's concerns?

### Operational guidance for the report

- **If a book-overview is in conversation**, reference its conclusions briefly. Don't re-derive what's already been derived.
- **If no book-overview**, do a fresh detective pass — name the situation, audience, and pressure-points before naming the purpose.
- The Author's Purpose at *passage* level may differ slightly from the book-level purpose — the passage serves the book's purpose by making a particular contribution. Name both.

### Book example (2 Timothy)

Paul writes from prison facing death; Timothy is a young leader facing false teaching and pressure to compromise. The book's purpose: *to urge Timothy to continue to stand for the true gospel despite the suffering that it will bring, in light of the glorious future that awaits him.* This reframes seemingly random doctrinal passages like 1:9–10 — they're not abstract theology, they're motivation to a wavering leader.

### Pitfall

Listing the "individual truths" of a passage without asking why they're being said *here, this way, to these people*. Missing the wood for the trees.

---

## 2. Context

**The question:** What comes immediately before and after, and how does that shape meaning?

**The principle:** "A text without a context is a con." The Bible is more like a novel than an encyclopaedia.

### Levels of context

1. Sentence within paragraph
2. Paragraph within section
3. Section within chapter
4. Chapter within book
5. Book within Bible (handled by Bible Timeline tool)

### What to do

- Read the verses immediately surrounding the passage.
- Read the section the passage sits in.
- Read enough of the wider book to understand its argument or storyline.
- **Don't trust** chapter/verse numbers, paragraph breaks, or editorial headings to mark the real divisions — they were added later and sometimes botched.

### Operational guidance for the report

- State what comes immediately before and what comes immediately after.
- Identify the section/larger unit the passage belongs to.
- Note how the passage advances, contrasts with, or completes what surrounds it.
- Flag if the passage is widely read out of context (e.g. John 12:32, Jer 29:11, Phil 4:13) — and if so, what the immediate context corrects.
- **When the preceding context includes a failure, misunderstanding, or blindness:** don't just note *that* it occurred — identify the *specific content* of what was missed. What should the character(s) have understood, and from what in the preceding text? In narrative where the passage directly addresses or illustrates a prior failure (disciples failing to grasp a miracle; hearers rejecting a teaching; a character acting in ignorance), the content of the failure is often the theological key to the passage. Name it precisely.

### Book example (2 Samuel 13)

Read alone, the chapter is incomprehensibly tragic — rape, murder, civil war. Read with the prior context (2 Sam 11–12: David's adultery, Nathan's prophecy "the sword shall never depart from your house"), every tragedy is the outworking of judgment. Without context, the events make no sense; with it, they teach the devastating consequences of sin.

### Positional Necessity Check *(universal — required for every passage)*

**This check applies to every passage in every biblical book, across all genres.** Every passage exists because of what has preceded it in the book's governing argument, narrative, or movement. A passage's position is not neutral; it is the author's argument. If you cannot answer why this passage exists *here*, you have not yet found its deepest meaning.

**The check has two required questions — always ask both:**

**Question 1 — The preceding-movement question:**
*What has the preceding argument, narrative, or movement predicted, required, made possible, or set up — that this passage now provides, answers, enacts, or resolves?*

**Question 2 — The necessity question:**
*Why does this passage exist here — after what has preceded it — and not somewhere else in the book?*

If you cannot answer Question 2, the answer to Question 1 is incomplete. Position is meaning.

---

**How the check operates by genre:**

The content of the answers differs by genre, but the questions are always the same.

| Genre | What "the preceding movement" typically is | What this passage typically provides |
|-------|-------------------------------------------|--------------------------------------|
| **NT epistle (doctrinal section → application)** | A sustained theological argument establishing gospel realities | The enacted, behavioural form of those realities ("therefore") |
| **NT epistle (implicit connection)** | A doctrinal movement that *predicts* something will happen without commanding it | The practical infrastructure for the predicted pattern — no explicit "therefore" needed |
| **OT narrative** | Earlier events, commands, failures, or prophetic words | Fulfilment, consequence, response, or the answer to an opened question |
| **Prophets** | An oracle of judgment, or an oracle of comfort | Its paired counterpart — comfort follows judgment; judgment follows complacency |
| **Psalms** | The psalm's own prior movement; the collection's sequence | Resolution, turn, doxological arrival — or deepening of the lament |
| **Wisdom** | The accumulated argument of the book | Application, embodiment, or the hard case the principle must cover |
| **Gospels** | The narrative setup of who Jesus is and what he has done | The scene, teaching, or miracle that requires that identification to make sense |
| **OT law** | The problem, crisis, or covenant term established earlier | The provision, regulation, or remedy the problem requires |
| **Apocalyptic** | The vision or throne-room scene that has established cosmic reality | The consequence, commission, or judgment that follows from it |

---

**The implicit-connection case (most commonly missed):**

The check is easiest to apply when there is an explicit connector ("therefore," "for this reason," "then"). It is most important — and most commonly missed — when the connection is *implicit*: the passage exists because the preceding movement has predicted a pattern, opened a question, or established a reality that now requires this passage, without naming it.

> **See also:** Tool 11 (Quotation/Allusion), step 3 *adjacency / narrative-pattern check* — when a source frame (e.g. a Sinai ascent) is established in an adjacent pericope, the preceding-movement question should also ask whether this passage *completes a two-stage OT pattern* from that source (e.g. the Exod 32 descent into chaos), even absent any verbal echo. Positional necessity and intertextual adjacency interlock: the reason a passage sits *here* is sometimes that it finishes a scriptural pattern the neighbouring passage began.

**Worked example — the failure this check is designed to prevent:**

Romans 14:1–15:13 sits in the paraenetic section of Romans (12–16). When audited in Claim Audit Mode, the explicit connectors were identified (the *dio* of 15:7, the *gar* of 15:8). But the implicit connection — the deeper reason the passage exists at all — was missed.

Question 1: *What has the preceding movement predicted that this passage enacts?* Romans 9–11, via Deuteronomy 32:21 (10:19) and 11:11-14 and 11:25-26, predicts that Jewish believers will come into Gentile communities as part of God's jealousy-strategy for saving Israel. This is not a historical contingency but a salvation-historical prediction built into the argument.

Question 2: *Why does 14:1–15:13 exist here, after chs. 9–11?* Because chs. 9–11 have predicted Jewish return, and the Gentile community must be equipped to receive Jewish believers without sabotaging the mechanism. The passage is the practical infrastructure for the jealousy-strategy. The Claudius expulsion is a historical instance of a theologically predicted pattern — not the interpretive foundation.

This reframe was only available by asking Question 2 before scoping any specific claim.

---

**Further examples by genre:**

*OT narrative:* Leviticus 16 (Day of Atonement). Q1: What has the preceding movement set up? Leviticus 10 — Nadab and Abihu die for unauthorized approach to God's presence. The crisis: God is unapproachably holy; the priesthood has no safe path into his presence. Q2: Why does Leviticus 16 exist here? It is the divinely provided answer to the Leviticus 10 crisis: one day a year, one high priest, one specified route, atonement made. Preach Leviticus 16 without Leviticus 10 and it is ritual detail; with it, it is the answer to an emergency.

*Prophets:* Isaiah 40:1 ("Comfort, comfort my people"). Q1: What has the preceding movement established? Isaiah 1–39 has prosecuted Israel's covenant failure and announced judgment, culminating in the Babylonian exile (39:5-7). Q2: Why does Isaiah 40 exist here? Because the preceding movement has established a people under judgment who need comfort that is only credible after the verdict has been heard. Preach Isaiah 40 as a standalone and it is warm but weightless; after Isaiah 1–39, the comfort lands with the full force of grace into condemnation.

*Psalms:* Psalm 23 within the Psalter. Q1: What has the preceding movement established? Psalms 1–22 have traced the life of the righteous person facing opposition, culminating in Psalm 22's total desolation ("My God, my God, why have you forsaken me?"). Q2: Why does Psalm 23 exist here? As the turn: after the lowest lament, the Lord as shepherd. Position gives Psalm 23 depth it lacks when read as a standalone funeral text.

*Gospels:* The Sermon on the Mount (Matthew 5–7). Q1: What has the preceding movement established? Matthew 1–4 has identified Jesus as Son of David, Son of Abraham, Son of God — the new Moses who has passed through water, wilderness, and temptation where Israel failed. Q2: Why does the Sermon exist here, on a mountain, with Jesus as the authoritative teacher? Because Matthew's opening has established who is speaking. The Sermon's authority ("but I say to you") only makes sense from this speaker, at this point in this narrative.

---

**What to include in the report:**

Under Tool 2 (Context), add a subsection *before* the general contextual notes:

```markdown
### Positional Necessity Check

**Preceding movement:** [Name what the preceding argument/narrative/movement has established, predicted, or required]

**Necessity answer:** [Why does this passage exist *here*, after *that* preceding movement?]

**Implication for this passage:** [How does the positional answer reframe or deepen the passage's meaning?]
```

This section should be brief when the answer is obvious and detailed when it is not — but it must always be present.

### Pitfall

The "encyclopaedia approach" — opening to a verse and reading it in isolation. Example: using John 12:32 ("when I am lifted up I will draw all men to myself") to talk about lifting Jesus up in praise, when the very next verse explains it referred to the manner of his death.

**The positional pitfall** — working a passage's internal evidence accurately while missing the reason the passage exists at this point in the book. This produces correct but incomplete exegesis. The internal evidence tells you *what* the passage says; the Positional Necessity Check tells you *why it is here* — which is often where the deepest meaning lives.
