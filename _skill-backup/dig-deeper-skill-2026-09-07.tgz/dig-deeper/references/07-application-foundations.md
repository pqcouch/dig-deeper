# Tools 13–16: Application Foundations

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 14–17.

These four tools share a function: they bridge *understanding the passage* and *applying it*. They guard against premature or wrong application.

---

## 13. Copycat

**The question:** Is what's described in the passage prescriptive (for us to follow) or merely descriptive (something that happened)?

**The principle:** "There is a danger in mistaking something the Bible *describes* for something it *prescribes*." Not everything done by a Bible character is good. Even good things aren't necessarily normative for every Christian.

### Three illustrative examples (from the book)

- Daniel ignores the king's edict and prays anyway → therefore we should obey God over men ✓ (other Scripture confirms)
- Samuel hears God's audible voice → therefore we should expect audible voices ✗ (this is the Bible Timeline + uniqueness)
- David sleeps with Bathsheba → therefore we can sleep with people who aren't our spouse ✗✗✗ (explicit Scripture forbids)

All three "use" the Bible the same way. The reasoning is wrong.

### Tests for whether a description is prescriptive

1. **Does the author indicate it's an example?** Sometimes yes — "*Now these things occurred as examples* to keep us from setting our hearts on evil things as they did" (1 Cor 10:6); "as an example of patience…take the prophets" (James 5:10).
2. **Does it cohere with the rest of Scripture?** If the answer is no, don't generalise from it.
3. **Is it part of a unique moment in salvation history?** Acts 8 (Samaritans receive the Spirit through apostolic hands) — a one-off frontier moment, not a template. Acts 2 (Pentecost) similarly singular. Joseph's prophetic dreams in Gen 37 — unique role in God's plan.
4. **Is the character a type of Christ rather than a model for us?** (See "Who Am I?" below.)

### A useful trichotomy

| Category | Example | Treatment |
|----------|---------|-----------|
| **Direct command** | "Love one another" (John 13:34) | Always applicable; the command itself is prescriptive |
| **Normative pattern** | The Bereans' careful study (Acts 17:11) | The author commends it; we imitate the underlying virtue |
| **Unique event** | Pentecost; Saul's Damascus road; the Transfiguration | Foundational but unrepeatable; we learn *about* it, not from it as method |
| **Negative example** | Wilderness grumbling (1 Cor 10:1–13 makes this explicit) | Warning, not template |
| **Descriptive only** | Many narrative details | Tells us what happened, not what to do |

### Book example (Gideon's fleece)

Some Christians "lay a fleece" to seek guidance (Judges 6:36–40). But Gideon wasn't seeking guidance — God had already told him clearly what to do. Gideon was seeking *reassurance* in his fear. The fleece was an act of weak faith, accommodated by a patient God — not a method to copy.

### Especially important for

Acts (narrative of unique moments), OT narratives generally, the lives of the patriarchs. Many Pentecostal/Charismatic debates and many ethical debates hinge on copycat decisions.

### Operational guidance for the report

- For **narrative passages**: walk the major characters/actions and label each: command / pattern / unique / negative / descriptive only.
- Note any places where the passage is *commonly* read as prescriptive that it shouldn't be (or vice versa).
- For **epistles, didactic passages, wisdom, poetry**: mostly **N/A** — no narrative characters to imitate. Note this with a brief reason.
- **When the passage includes a healing, miracle, or act of divine initiative:** in addition to labelling the event (descriptive / unique / etc.), ask — what does the *manner or mechanism* of the act suggest about the congregation's posture before God? Specifically: does Jesus act without the recipient's effort (sight given; strength restored; the dead raised) or in response to the recipient's action? Passive-receipt acts imply dependence and petition as the right posture; they should not be converted into prescriptions for imitation but may suggest an application posture (e.g., "receive what he gives" rather than "try harder"). This is distinct from asking whether to copy the act; it is asking what the *shape* of the act reveals about how God works.

### Pitfall

Reading every narrative as "what should I copy here?" Missing that some narratives exist to show what *not* to do (Judges generally), or to point to Christ (Joseph, David, Moses).

---

## 14. Bible Timeline

**The question:** Where on the redemptive-historical timeline does this passage sit? Where am I? How does what's happened between change how I read this?

**The principle:** The Bible is one big story. Where a passage sits in that story shapes how a Christian today reads it.

### The three questions

1. Where is this passage on the Bible timeline?
2. Where am I on the Bible timeline?
3. How do I read this in the light of things that have happened in between?

### The timeline

Creation → Fall → Patriarchs → Egypt/Exodus → Sinai → Conquest → Judges → Monarchy → Divided Kingdom → Exile → Return → 400 silent years → **Christ (incarnation, death, resurrection, ascension, Pentecost)** → Church age → **(We are here)** → Christ's return → Judgment → New creation

### Common timeline-driven misreadings

| Misreading | Where it goes wrong |
|------------|---------------------|
| "Christians must keep the dietary laws" | Pre-cross OT law, fulfilled in Christ (Mark 7:19; Acts 10) |
| "Genesis 1 proves original goodness of humanity" | Gen 1 is pre-fall; Gen 6 says "every inclination of the thoughts of his heart was only evil" |
| "Christians inherit the literal land of Canaan" | Heb 11:16 reframes the land promise toward the heavenly country |
| "The temple will be rebuilt and sacrifices resumed" | Christ is the temple (John 2); sacrifice complete (Heb 10) |
| "Apply Israel's national promises directly to my nation" | Confuses Israel and the church; misses Christ as fulfilment |
| "We need a 'second Pentecost'" | Pentecost is foundational and unrepeatable |

### "Russian dolls" timeline

There's a miniature timeline within the OT — Israel were slaves in Egypt (= our slavery to sin), redeemed at Passover (= Christ's death), wandered in the wilderness (= our present pilgrimage), entered the promised land (= heaven). This parallel means OT exodus passages have real application to NT believers (1 Cor 10:1–13; Heb 3–4 on Ps 95).

### When the tool isn't needed

Passages about God's *unchanging character* (Mal 3:6; Heb 13:8). God is the same in Deuteronomy and Galatians.

### Operational guidance for the report

- For OT passages: locate the passage on the timeline. Identify what has happened *since* that materially affects how a Christian reads it (especially the cross and resurrection).
- For NT passages: usually a brief note — "this side of the cross, awaiting consummation". Add detail only if the passage is about the Christian's "in-between" location.
- Watch for **passages commonly applied with the timeline ignored** (the land promise; OT prosperity language; OT national-Israel promises).
- If the passage is about God's character, note that the timeline tool isn't required — God is the same.

### Book example (Leviticus 4:27–31)

Goat sacrifice for unintentional sin. You don't slaughter goats because Christ's death is the final sacrifice (Heb 10:1); the goats were a shadow. Leviticus still teaches — sin is serious, death is required, blood-shedding brings cleansing — but read through the cross.

### Pitfall 1

Importing OT promises directly to modern Christians without filtering through Christ.

### Pitfall 2

Dismissing the OT as "not for us" — Paul says it *was* written for us (Rom 15:4; 1 Cor 10:11). The answer is *neither* direct application *nor* dismissal but reading through the redemptive-historical lens.

> **See also:** `extensions/christological-reading.md` for fuller typological work — how OT figures, institutions, and events point to Christ.

---

## 15. Who Am I?

**The question:** Which character (if any) am I to identify with in this passage?

**The principle:** "*Moses isn't me.*" The default human instinct is to read ourselves into every story as the hero. But often the OT hero is a type of Christ — not of me. The "Moses-is-me syndrome" misreads the Bible.

### The categories

| The passage's character | Most often, this is... |
|-------------------------|------------------------|
| David facing Goliath | Christ defeating God's enemies on our behalf — not "your giants" |
| Moses delivering Israel from Egypt | Christ as our mediator and deliverer — not "I am Moses" |
| Elisha doing mighty miracles | Christ as the powerful saviour — not "we should do these miracles" |
| The suffering righteous (Ps 22, lament psalms) | Christ — Ps 22 fits the cross before anyone else |
| The grumbling Israelites in the wilderness | **Us** — 1 Cor 10:1–13 (this one we *do* identify with — as warning) |
| Believers in the NT epistles | **Us** — directly addressed to the church |

### Sometimes we *are* right to identify with OT figures

- David's experience of forgiveness in Psalm 32 (Rom 4:6–8 says we share it)
- Moses' faith in choosing the people of God (Heb 11:24–26 holds him up as example)
- The faithful in Hebrews 11

### Sometimes the villains, not the heroes, are us

- Rom 3:9–18 applies David's lament-Psalm denunciations of "the wicked" to all humanity.
- 1 Cor 10:1–13 explicitly says the wilderness Israelites are warnings for us.

### Categories to consider

For each major character/group in the passage, ask:

| Category | When |
|----------|------|
| **Type of Christ** | OT mediator, king, priest, prophet figures; OT suffering righteous |
| **Direct example for us** | When NT explicitly applies (David in Rom 4; Moses in Heb 11; "as examples" — 1 Cor 10:6, James 5:10) |
| **Negative example / warning** | When NT explicitly warns from them; when narrator's verdict is condemnatory |
| **Recipient of the message** | When the original audience's situation maps to ours |
| **Foil to highlight the protagonist** | Pharaoh next to Moses, Saul next to David — they exist to make the other visible |
| **Representative of humanity broadly** | "Adam" passages; "every man" psalms |

### Book example (Exodus 3, the burning bush)

The Bible-study question "What burning-bush experiences have you had?" is twice wrong — confuses narrative with metaphor (Genre tool), and assumes Moses-is-me when Moses is being commissioned as Israel's mediator (a role Christ fulfils).

### Book example (John 14:26)

"The Holy Spirit will teach you all things and will remind you of everything I have said to you." If addressed directly to us, we don't need to read the Bible. But it's addressed to the apostles, who would write the NT. The right question: "What does it mean to me *that Jesus said this to them*?" Answer: I can trust the NT.

### Operational guidance for the report

- For each character/group in the passage, name their function: type of Christ / example / warning / recipient / foil / representative.
- Where the passage is commonly misread as "me", flag it.
- Where the passage genuinely is direct address (NT epistle to the church, Pauline imperative), say so — "Who Am I?" is short and obvious.

### Pitfall

Reading every OT narrative as "what's my Goliath?" Reading every promise to the apostles as a direct promise to me. Conversely, denying *any* identification when Scripture explicitly invites it.

---

## 16. So What?

**The question:** What response does the author seek? What does this mean for my life?

**The principle:** "It is possible to be an expert in understanding the Bible and for it to do you no good whatsoever." Application is not optional. But the previous three tools (Copycat, Bible Timeline, Who Am I?) warn against jumping there *too quickly*.

### Two stages

**Stage 1:** Work out the response the author was looking for. This is Author's Purpose applied. What is the passage *doing*?

**Stage 2:** Translate that into the nitty-gritty of life.

### Two basic action questions

- Do I need to **stop** doing something?
- Is there something new I should **start** doing?

### Beyond behaviour — worldview

The Bible doesn't only change actions; it changes how we *think*. Worldview shapes living. If someone believes there is a loving God who sent his Son to die for them, that person will live to please him.

So: "What does this passage tell me to **do**?" AND "How does it tell me to **think**?"

### Motives matter

"Flee from sexual immorality" (1 Cor 6:18) is a bare command. But Paul *gives motives* — your body is a temple of the Holy Spirit; you are not your own; you were bought at a price. Application without motive is moralism; biblical application flows from gospel reality.

For the report: when the passage gives a command, note the motivation alongside it.

### Four audiences

| Audience | Question |
|----------|----------|
| **For me** | What does this mean for my own walk? *Don't skip — speck/plank.* |
| **For a Christian friend** | Who do I know who needs this word right now? |
| **For the church community** | How does this address us together (often the plural "you" in the original)? |
| **For an unbeliever** | What does this mean for those who don't yet know Christ? |

### Prayer

Application should drive prayer:
- "Sorry for X, which your word has shown to be wrong in my life."
- "Thank you for Y, which you've shown us this evening."
- "Please, by your Spirit, give me power to change Z."

The "two-way conversation" of God's Word + our prayer is the model (Neh 8–9).

### Operational guidance for the report

This section should be **rich but disciplined**. Avoid:
- Moralism (bare imperatives without gospel motivation)
- Premature application (jumping past Copycat/Timeline/Who-Am-I work)
- Application that contradicts the previous three tools

Structure:
- Stage 1: name the author's intended response (one or two sentences)
- Stage 2: worldview + behaviour (stop/start) + motivation
- Four audiences, briefly
- Prayer in response

Hand-off note: this section feeds **Purpose Statement** work in `/point-purpose`.

### Book example (Revelation 21:1–4)

"A new heaven and a new earth". No explicit imperative. But it shapes worldview: *Do I really believe the world is heading there? Does this future give me hope? Am I looking forward to it?* The Author's Purpose tool (Revelation addressed to suffering Christians, 1:9) shows this future *changes how I view suffering now*, and *changes whether I'll tell others about Christ*. Prayer follows.

### Pitfall

Treating Bible study as information without obedience. Jumping to application before the previous tools have done their work. Skipping the "for me" question. Bare imperatives without gospel motives (moralism).
