# Extension: Textual Variants

Manuscript-level variations in the Greek NT or Hebrew/Aramaic OT that affect how a passage should be preached. This extension is **passage-specific** — most passages have no variants worth flagging.

The goal: ensure the preacher doesn't preach a contested verse without knowing it's contested, and doesn't make a doctrinal point from a verse that the best manuscripts omit.

---

## When to use this extension

| Definitely flag | Skip |
|-----------------|------|
| The passage contains or sits adjacent to a major variant (see catalogue below) | The passage has only minor spelling/word-order variants with no meaning impact |
| The passage is doctrinally significant and a variant affects the doctrine | The passage has stable text across all major manuscript traditions |
| Modern translations differ on whether to include the words | All translations agree on the words |
| The variant has homiletic implications (e.g., preaching the long ending of Mark) | Variants entirely below preacher's working level |

---

---

## Governing rule for the OT: the three-way triage

**Where the Hebrew and the Greek diverge, there is no blanket preference for either.** A divergence is not one kind of thing, and the commonest error in OT work is to treat all three of the following as the same finding — usually by collapsing them into "the LXX is less reliable". **Classify first, then report.** Only category 2 belongs in this extension at all.

### 1 — Translation loss (not a variant)

The Hebrew carries a literary feature that no translation into any language can carry: a repeated root, a wordplay, a Leitwort, a count of formulaic occurrences, a pun on a name. The Greek "breaks" it because *translation* breaks it. So does the ESV.

| | |
|---|---|
| **Belongs in** | Tool 7 (Vocabulary), Tool 8 (Translations), or `original-languages.md` |
| **Report as** | a fact about the Hebrew, noting that the Greek cannot carry it |
| **Do not report as** | a reliability judgement, a text-critical finding, or a `**Translation-tradition split:**` |

**Standing formula for counts.** Where a report gives a count of anything — occurrences, formulae, divine speeches, compliance-refrains — state or imply **"in the Hebrew"**. A count is a feature of a language, not of a book.

*Worked examples.* *Tēbâ* (Exod 2:3, 5) is shared in the Hebrew Bible only with Noah's ark, but the LXX renders it θῖβις here and κιβωτός at Gen 6:14 — the link is real and simply cannot survive into Greek. *Pānîm* at Exod 33:14 is resolved to αὐτός, breaking the face/presence hinge on which the chapter turns. Neither is evidence about the LXX's quality.

### 2 — Substantive variant (no default; weigh it)

The Greek reflects a different *Vorlage*, a different recension, or a whole different edition — a clause absent, a law materially different, a book differently arranged. **This is the only category this extension carries.**

**There is no presumption in favour of the MT.** The LXX translates a Hebrew text that is sometimes older than the Masoretic, and Qumran has vindicated it in real places:

- **LXX Jeremiah** is roughly an eighth shorter and differently arranged, and **4QJer-b supports the shorter Hebrew** — so the LXX is here a witness to a genuinely earlier edition, not a loose translation.
- **4QSam-a** repeatedly sides with the LXX against an MT that has suffered haplography in Samuel.
- **Deut 32:8** — "sons of God" (LXX + 4QDeut-j) against MT's "sons of Israel" — now stands in the **ESV text**, not merely its footnote.

*Weigh case by case:* external evidence (age, breadth, Qumran); which reading explains the other; whether the difference is the translator's habit or his *Vorlage*; whether the shorter or the harder reading is likelier original.

*Report as:* a variant with both readings, the manuscript evidence, a stated position **and a confidence flag** — never a bare preference. Where the scholarship is genuinely unsettled, **say so and stop**, rather than resolving it by default.

*Worked examples.* The LXX's **absence of Exod 32:9**, which makes "stiff-necked" fourfold in Hebrew and threefold in Greek. The **materially different law at Exod 21:22–25** (the formed/unformed distinction). **LXX Exodus 35–40**, shorter and differently ordered — the largest divergence in the Pentateuch, and one where **which edition is prior is genuinely disputed**; a report should present the dispute, not pick a side.

### 3 — The Greek as the NT's own text (stands regardless)

Where the NT quotes or argues from the Greek, that rendering is a fact about **how the NT reads the OT**, and it is load-bearing whichever text is prior. **Never set it aside on the ground that the Hebrew is the original** — that would put the report at odds with the apostles' own practice.

| | |
|---|---|
| **Belongs in** | Tool 11 (Quotation/Allusion) or `biblical-theology.md`, cross-referenced from Tool 8 |
| **Report as** | a canonical-reading finding |
| **Do not report as** | a translation error, or a place where the Hebrew "corrects" the Greek |

*Worked examples.* *Kappōret* → *hilastērion* → Christ as *hilastērion* (Rom 3:25; Heb 9:5). *Tabnît* → *typos* → "according to the pattern shown you on the mountain" (Heb 8:5). *Qāran* at Exod 34:29 → **δεδόξασται**, "had been glorified" — which is what Paul's entire *doxa* argument in 2 Cor 3:7–18 is reading. Hab 2:4 as quoted at Rom 1:17, Gal 3:11 and Heb 10:38.

### The working default, stated plainly

English OTs — the ESV included — translate the Masoretic text. **The report's working text is therefore already Hebrew, and needs no rule to make it so.** The confessional warrant for privileging the Hebrew (WCF 1.8: the OT "in Hebrew… immediately inspired by God, and by his singular care and providence kept pure in all ages") is a claim about the Hebrew **original** and about providential preservation. It is not a ruling on any particular variant, and the Reformed themselves kept the two apart — that distinction was much of what Owen and Walton were arguing about over the London Polyglot. **Preserve it here: work from the Hebrew, and still weigh the variant on the evidence.**

### Why the blanket rule is refused

A standing preference for the Hebrew sounds safe and produces three specific failures:

1. **A translation-loss finding dressed up as a text-critical one** — inflating "Greek can't do wordplay" into "the Greek is corrupt here".
2. **A genuine variant decided by default rather than by evidence** — which puts the report on the wrong side of Deut 32:8, LXX Jeremiah, and much of Samuel.
3. **An NT argument quietly undercut** because it rests on a Greek reading the rule has just demoted.

**If a report cannot say which of the three categories a divergence belongs to, it has not yet done the work.**

## Catalogue of NT variants preachers should know

| Reference | Issue | Major position | Implication |
|-----------|-------|----------------|-------------|
| **Mark 16:9–20** | The "long ending of Mark" — absent from oldest manuscripts (Sinaiticus, Vaticanus) | Most scholars regard it as a later addition; modern translations bracket or footnote | Don't build doctrine on snake-handling or universal sign-gifts from these verses |
| **John 7:53–8:11** | The pericope adulterae (woman caught in adultery) — absent from oldest manuscripts; floats to different positions in others | Likely not original to John but considered authentic tradition by many | Acknowledge the textual question; can still preach it carefully |
| **1 John 5:7–8** ("Johannine Comma") | "...the Father, the Word, and the Holy Spirit; and these three are one. And there are three that bear witness on earth..." | Absent from all Greek manuscripts before the 14th century; KJV included via Latin Vulgate | Don't build Trinity doctrine on this verse — there are better verses |
| **Matthew 6:13b** ("for thine is the kingdom...") | Doxology of the Lord's Prayer | Absent from earliest manuscripts; ESV/NIV footnote; KJV includes | The traditional liturgical ending, but not in the original |
| **Mark 1:1** ("Son of God") | Some manuscripts omit "Son of God" | Most include; some early manuscripts omit | Generally accepted as original; minor issue |
| **Luke 22:43–44** (angel strengthening; bloody sweat) | Absent from some early manuscripts | Modern translations often bracket | Authenticity debated; many preach carefully |
| **Acts 8:37** | The Ethiopian eunuch's confession | Absent from earliest manuscripts; modern translations omit | Don't base baptismal-confession theology on this verse |
| **John 5:3b–4** | The angel troubling the water at Bethesda | Absent from earliest manuscripts | Modern translations omit |
| **Romans 8:1** | KJV adds "who walk not after the flesh, but after the Spirit" | Earliest manuscripts have just "no condemnation"; the addition is from v. 4 | The unconditional "no condemnation" is original |
| **Romans 16:24** | "The grace of our Lord..." | Absent from earliest manuscripts | Modern translations omit or footnote |
| **Ephesians 1:1** ("in Ephesus") | Some manuscripts omit "in Ephesus" | Possibly originally a circular letter | Affects how we read Ephesians' situation |
| **Colossians 1:14** | KJV adds "through his blood" | Borrowed from Eph 1:7; not in earliest Colossians manuscripts | The shorter reading is original |
| **1 Timothy 3:16** | "God [or 'He who'] was manifest in the flesh" | KJV "God"; modern translations "He" | Possibly affects an explicit-deity-of-Christ proof-text |
| **Mark 9:29** | "by prayer [and fasting]" | "And fasting" absent from earliest manuscripts | Practical implications for preaching the demoniac story |
| **John 1:18** | "only begotten Son" / "only begotten God" / "the unique one, God" | Earliest manuscripts: *monogenēs theos* (unique God) | Strong Christological claim if "God" is original |

---

## Catalogue of OT variants preachers should know

The Hebrew OT is transmitted more uniformly than the Greek NT, but uniformity of transmission is not the same as priority of reading — several of the following are places where the LXX (often with Qumran support) has the better claim. Run each through the **three-way triage** above before reporting it; all of the entries below are category 2.

| Reference | Issue | Implication |
|-----------|-------|-------------|
| **1 Samuel 17 (David & Goliath)** | LXX and DSS sometimes differ from MT on details (e.g., Goliath's height — 4 vs 6 cubits) | Affects fine details, not the story |
| **Jeremiah** | LXX Jeremiah is ~14% shorter than MT and arranged differently | Major book-level variation; rarely affects individual sermons |
| **Psalm 22:16** | MT: "like a lion" (*ka'ari*); LXX/DSS: "they pierced" (*ka'aru*) | Significant for Messianic/crucifixion reading |
| **Deuteronomy 32:8** | MT: "sons of Israel"; DSS/LXX: "sons of God" | Significant for divine-council reading |
| **Genesis 4:8** | MT lacks Cain's actual words to Abel; Samaritan + LXX include "Let us go out to the field" | Minor — completes the scene |
| **1 Samuel 13:1** | MT has gap in Saul's age and reign length | Hard to translate; many English versions guess |
| **2 Samuel 8:7** vs **1 Chronicles 18:7** | Numerical and minor detail differences | Synoptic OT issue |
| **Habakkuk 2:4** | MT: "the righteous shall live by his faith[fulness]"; LXX has variants quoted in NT (Rom 1:17; Gal 3:11; Heb 10:38) | Translation choice affects the use of the verse in NT theology |

---

## Apparatus to consult

For serious work:
- **NA28 / UBS5** Greek NT critical apparatus
- **BHS / BHQ** Hebrew OT critical apparatus
- **NET Bible translator notes** (free online — excellent layman-friendly textual notes)
- **Metzger's *Textual Commentary on the Greek New Testament***
- **Comfort's *New Testament Text and Translation Commentary***

---

## Operational guidance for the report

If the passage has **no** variants worth flagging, this section is a single line:

> "No significant textual variants in this passage."

If the passage **does** have variants, structure:

```markdown
## Textual Variants

### [Verse reference]

- **The issue:** [what varies]
- **Manuscript evidence:** [briefly — which manuscripts have what]
- **Most likely original:** [position, with confidence]
- **Preaching implication:** [should the preacher mention this? Build doctrine? Acknowledge in passing? Avoid the disputed reading?]
- **Confidence:** *high / moderate / uncertain — consider verifying*
```

---

## What this extension is *not*

This is not "every variant for every verse". The Greek NT has ~400,000 variants. Most are spelling errors, transposed letters, or trivial. Surface only the ones that:

1. Affect translation meaningfully
2. Affect doctrinal teaching
3. Affect what the preacher should or shouldn't say
4. Are likely to come up if a congregation member compares translations

---

## Pitfall

Over-confidence about variant decisions Claude isn't sure about. **Always flag confidence**, and when uncertain, recommend the NET Bible notes (most accessible) or a commentary with textual criticism.

Also: don't make the textual-variant section into a paragraph of footnotes for show. The test is whether the variant matters for *this* sermon.

**And the OT-specific pitfall:** resolving a Hebrew/Greek divergence by a standing preference for either text instead of by the triage. Category 1 is not a variant, category 2 has no default, and category 3 stands whichever text is prior.
