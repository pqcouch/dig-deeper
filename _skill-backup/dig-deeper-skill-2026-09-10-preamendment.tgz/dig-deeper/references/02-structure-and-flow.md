# Tools 3–4: Structure and Linking Words

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 4–5.

---

## 3. Structure

**The question:** How has the author divided his material into sections, and how do those sections fit together?

**The principle:** "Lots of the meaning is in the structure." Apply at multiple levels — whole book down to single passage. Aim for 2–5 sections; more than that becomes fragmented.

### What to do

- Mentally strip out chapter, verse, paragraph and heading marks. They were added later.
- Look for **explicit dividers**: repeated phrases ("the next day" in John 1:19–51), changes of voice (Isaiah 40:3–11), scene changes in narrative, stages in an argument in epistles.
- For each section, give it a working title.
- Ask how the sections fit: contrasting, complementing, building, climaxing.
- If sequential subdivision doesn't work, try **thematic** division — 2–3 key topics woven throughout.

### Special structures

**Bookends (inclusio):** Same phrase at start and end of a section, signalling everything in between belongs together.
- Romans 1:5 and 16:26 both speak of "the obedience of faith".
- Matthew 5:3 and 5:10 both "for theirs is the kingdom of heaven".

**Sandwich:** Two different episodes interleaved to highlight a connection.
- Mark sandwiches the fig tree cursing around the temple cleansing — fig tree = temple, judged for fruitlessness.
- Ezekiel's commissioning (2:1 – 3:11) is sandwiched between two glory visions — his words come from the Lord of glory.

**Chiasm:** A-B-C-B'-A' structure where **the centre is the point**. Mostly OT, occasionally NT.
- Daniel 2–7 is a six-chapter chiasm; the centre (chs 4–5) is God's sovereignty in deposing kings.
- Jonah 1 chiasm centres on Jonah's profession "I fear the LORD" (v.9) — placed there ironically.
- John 1:1–2 is a small chiasm.

### Genre-specific reading

| Genre | Look for |
|-------|----------|
| Narrative | Scene changes, character entrances/exits, location shifts, time markers |
| Dialogue | Speaker changes |
| Pauline letter | Stages in argument: indicative → imperative, problem → solution, objection → response |
| Psalm | Refrains, selah breaks, shifts of address (to God / about God / to self / to congregation) |
| Wisdom | Topic units, contrasts, illustrations |
| Apocalyptic | Vision boundaries, sequence markers ("and I saw...", "after this..."), repeated cycles |

### Operational guidance for the report

- Lay out the structure as a small table: verses → section title → function.
- Name the structural device (linear, bookends, sandwich, chiasm, thematic).
- Note how the sections relate to each other and what that relationship contributes.
- For an epistle or argument-heavy passage, the *section* table is not enough on its own. Run the **Clause-Flow Layout** (below) to expose the structure *within* each section — which clause is load-bearing and which are subordinate. This is what tells you the central assertion of each section, and it is the raw material the downstream `/point-purpose` and `/seven-second-sermon` skills turn into didactic headings.

### Pitfall

Trusting publisher-supplied section headings. Forcing a sequential subdivision when the material is thematic. Multiplying sub-divisions until the passage fragments.

---

## 4. Linking Words

**The question:** What logical connectors are present, and how do they reveal cause-and-effect, conditions, and purpose?

**The principle:** "If you see a 'therefore', always ask what it's *there for*."

### The arrows

| Arrow type | Words | What follows the arrow |
|------------|-------|------------------------|
| →*therefore*→ | therefore, consequently, for this reason, thus, so | the **result/consequence** |
| ←*for*← | for, because, since, so | the **reason/explanation** |

You can flip a "for" statement into a "therefore" statement and get the same meaning.

### "If" statements

Two types:
- **Conditional** (uncertain): "*If* you obey God's commands, you will be blessed" (Deut 28). Blessing is contingent.
- **Evidential** (certain — close to "because"): "*If* God did not spare angels..." (2 Pet 2:4–9). No doubt is implied; "because" substitutes cleanly.

### "So that"

- Sometimes **purpose** ("I write this *so that* you may not sin" — 1 John 2:1)
- Sometimes **result** ("a crowd gathered *so that* they were trampling one another" — Luke 12:1)

Context decides which.

### Other connectors to track

| Connector | Function |
|-----------|----------|
| **but** / *however* / *yet* / *nevertheless* | Contrast — flags the pivot point |
| **and** | Continuation — often glossed but sometimes carries weight |
| **even** / *also* / *indeed* | Emphasis or extension |
| **now** | Temporal shift or topic shift |
| **as** / *just as* | Comparison |
| **though** / *although* | Concession |
| **in order to** / *that you may* | Purpose |
| **until** / *while* | Temporal frame |

### Operational guidance for the report

- For an epistle or argument-heavy passage, **trace every connector** — this is often where the meaning lives.
- For narrative or poetry, list the few significant ones and skip the rest.
- Use arrow notation (→therefore→, ←for←) where it helps clarity.
- Watch especially for connectors that get **dropped or smoothed by dynamic translations** (cross-reference with the Translations tool).

### Book example

2 Corinthians 1:8–9 — "we felt that we had received the sentence of death *so that* we would rely not on ourselves but on God who raises the dead". Combined with 2 Cor 4:7 ("clay jars...*so that* it may be made clear that this extraordinary power belongs to God"), the "so that"s show God's chosen pattern: cheap container, treasure inside, glory unambiguous.

### Pitfall

Skipping connectors. Treating "so that" as always purpose when sometimes it's result. Missing connectors that the translation has quietly dropped.

---

## Clause-Flow Layout — putting Tools 3 and 4 to work (epistles & discourse)

**The question:** Below the level of *sections*, how do the individual clauses relate — which clause is the main assertion, and which clauses merely modify, explain, motivate, or qualify it?

**Why it earns its place:** Tool 3 finds the *sections*; Tool 4 finds the *connectors*. Neither, on its own, tells you the **load-bearing clause of each section** — the one assertion the rest of the section serves. That clause is the section's centre of gravity, and surfacing it is the single most useful thing this skill can hand to `/point-purpose`: a section whose central clause is a command will be preached differently from one whose central clause is a statement of truth. For argument-heavy genres (Pauline and General Epistles, discourse, reported teaching) this layout is the primary structural tool. (For poetry, the equivalent work is parallelism — Tool 5; for narrative, it is scene-tracking — the genre table under Tool 3.)

### The principle

Meaning rides on arrangement. You cannot reorder an author's clauses and keep his meaning — so laying the clauses out *as he ordered them*, but spatially, makes the subordination visible. The layout keeps **every word, in the same order**; it only adds line-breaks and indentation so the logic shows.

### Method

1. **Write the clauses out, same words, same order**, one clause (or phrase) per line.
2. **Indent to show subordination.** The main clause sits flush-left. Anything that *depends on* it — a reason (←for←), a result (→therefore→), a purpose (so that), a condition (if), a contrast (but), a participle, a modifying phrase, an item in a list — is indented underneath the clause it serves. Indentation = "this hangs off that."
3. **Tag the verbs by mood** — this is often the key to the structure:
   - **Imperatives (commands)** — what the author tells the readers to *do*. Mark them (Boon highlights every command). In some books the imperatives *are* the skeleton: find the commands and you have found the sections (1 Peter behaves this way more than Paul does).
   - **Indicatives (statements of truth)** — what the author says *is the case*. Distinguish these sharply from commands; confusing "you have been filled in him" (truth) with "see to it" (command) wrecks the structure.
   - **Participles** typically hang *under* their controlling verb, spelling out how the main verb is carried out. Col 2:6–7: the imperative is *walk in him*; "rooted", "built up", "established", "abounding in thanksgiving" are participles indented beneath it — they describe the walking, they are not four new commands.
4. **Stack lists.** Conceptually parallel items (a string of adjectives in Titus; "according to human tradition / according to the elemental spirits / not according to Christ" in Col 2:8) go one above the other at the same indent — they share one role in the sentence.
5. **Read off the load-bearing clause.** Once laid out, the flush-left clause of each section is its central assertion. State it for each section.

### A left-to-right heuristic (use with the caveat)

As a secondary aid, the further left a clause sits, the more *grammatically* central it is; deeply indented material is supporting. **Caveat (important):** "grammatically central in this sentence" is not the same as "the most important truth in the universe." "I put my Bible — *which is the very word of God* — on the desk" is grammatically *about* putting it on the desk; the parenthesis is the weightier truth globally. So use left-to-right to find *what this sentence is mainly asserting*, not to rank truths by importance. Where the two big halves of a section could plausibly go either way (which is primary, the command or its motivating truth?), the layout's job is to establish the *indentation* (which clause is subordinate to which) — deciding which half is primary may need the wider flow of the argument, and it sometimes doesn't matter much.

### Worked micro-example — Colossians 2:16–17

```
Therefore let no one pass judgment on you            ← main clause (3rd-person imperative / command)
    in questions of food and drink,                  ← what they might judge you over (list)
    or with regard to
        a festival
        or a new moon
        or a Sabbath.                                ← sub-list of three
These are a shadow of the things to come,            ← statement of truth
    but the substance belongs to Christ.             ← contrast (but) — the pivot
```

Load-bearing clauses: a **command** ("let no one pass judgment on you", v.16) and a **truth** that grounds it ("the substance belongs to Christ", v.17). Two sections, command + truth — which is exactly the shape a two-point talk would reflect. (Note for downstream: this is *passage* structure, not sermon structure — naming the two central assertions is exegesis; turning them into headings is `/point-purpose` and `/seven-second-sermon` work.)

### Operational guidance for the report

- Produce the layout for the passage (a fenced code block preserves the indentation) **only where genre warrants** — epistle/discourse/reported-teaching. For poetry and narrative, say so and point to Tool 5 / the genre table instead.
- After the layout, list the **central assertion of each section in one line**, and tag its mood (command / truth). This is the hand-off to `/point-purpose`.
- Warrant: the layout itself is normally `[T]` (it rearranges only whitespace); mood-tagging that depends on the Greek is `[T]` if checked, `[I]` if inferred from the English — flag accordingly and cross-reference the Original Languages extension where a participle/imperative call is load-bearing.
- This is an art, not a science. Where two arrangements are both defensible, show the one you think likeliest and note the alternative rather than forcing false certainty.

### Pitfall

Reading the layout off a commentary's outline rather than the text (a text-first violation — the value is in laying it out from the words yourself). Treating every clause as equally central (then there is no structure). Mistaking a participle or a "for" clause for a new main point. Letting the left-to-right heuristic override the plain force of the passage.
