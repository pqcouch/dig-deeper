# Tools 5–6: Parallels and Narrator's Comment

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 6–7.

---

## 5. Parallels

**The question:** Is there Hebrew-style parallelism, and what does the pairing reveal?

**The principle:** Hebrew poetry's basic device is parallelism, not rhyme. The same idea is stated twice in slightly different words — two chances to understand it. The parallel pairing can also unlock obscure expressions.

### Three types

**Synonymous:** Second half restates first.
> "The earth is the LORD's, and everything in it /
> the world, and all who live in it" (Ps 24:1)

**Antithetical:** Second half contrasts with first.
> "A fool gives full vent to his anger /
> but a wise man keeps himself under control" (Prov 29:11)

**Chiastic:** Second half flips word order.
> "the torrent would have gone / over us; /
> then over us / would have gone the raging waters" (Ps 124:4–5)
>
> The "us" is poetically trapped in the middle, swamped on both sides.

### Other patterns worth noticing

| Pattern | Description | Example |
|---------|-------------|---------|
| **Synthetic** | Second line extends/develops first | Ps 19:7a → 7b |
| **Climactic / staircase** | Repetition that builds | Ps 29:1–2 ("ascribe...ascribe...ascribe") |
| **Emblematic** | Image in one line, application in other | "As a deer pants...so my soul pants" (Ps 42:1) |

### What to do

- Mostly relevant for Psalms, Proverbs, prophets, OT poetry, parts of the Gospels with poetic registers (Magnificat, Beatitudes).
- Also illuminates prose where parallel structures appear (e.g., 2 Tim 2:11–13 "trustworthy saying" is in parallel form).
- When a verse contains parallel pairing, **use the second half to interpret the first** (and vice versa).
- Watch for **deliberate breaks** in parallelism — when a poem mostly follows the pattern and then breaks it, the break is significant.

### Operational guidance for the report

- For Psalms or Proverbs, parallelism is everywhere — be selective: list 2–4 parallels that *clarify meaning* rather than every pair.
- For prose, flag the few parallel constructions that materially affect meaning.
- **N/A** with one-line reason for non-poetic NT prose where there's no parallel construction.

### Book example (2 Timothy 2:11–13)

> If we died with him / we will live with him
> If we endure / we will reign with him
> If we disown him / he will disown us
> If we are faithless / he will remain faithful

The first two pairs treat the halves as equivalent positives. The third pair makes "disown him → he disowns us" the equivalent of "are faithless → he remains faithful". So God's "remaining faithful" means **faithful to his word of judgment** — disowning the faithless. The parallel structure determines that v.13 is warning, not comfort.

### Pitfall

Missing the parallel because of the visual layout. Treating one half as the "real point" and the other as filler. Reading antithetical parallels as synonymous (or vice versa).

---

## 6. Narrator's Comment

**The question:** Does the author break into the narrative to explain or interpret events?

**The principle:** Sometimes events alone are ambiguous. The author whispers, "This is what is going on!" These asides are the author's authoritative interpretation of his own story.

### What to do

Read narrative looking for sentences that aren't part of the action but step outside to comment. Watch for:

| Type | Examples |
|------|----------|
| **Fulfilment formulas** | "And so was fulfilled what the Lord had said..." |
| **Editorial asides** | "So Esau despised his birthright" (Gen 25:34) |
| **Decoder explanations** | "But the temple he had spoken of was his body" (John 2:21) |
| **Repeated narrator refrains** | "In those days Israel had no king; everyone did as he saw fit" (Judg 17:6 + 18:1 + 19:1 + 21:25) |
| **Theological verdicts** | "He did what was right / evil in the eyes of the LORD" (Kings refrain) |
| **Foreshadowing** | "But Joseph found favour..." (Gen 39:21 framing the whole arc) |
| **Inside character information** | "Now Esau hated Jacob" (Gen 27:41) — knowledge readers couldn't otherwise have |

### Operational guidance for the report

- For narrative, **identify every authorial intrusion**, however brief. These are interpretive gold.
- Distinguish narrator comments from character speech — characters can be mistaken; the narrator is authoritative.
- Note when a narrator refrain repeats — that repetition is itself a structural signal.
- For John especially, watch for clarifying asides like "now he said this..."

### Book examples

**Genesis 25:29–34.** Esau sells his birthright for stew. Read the events alone and he looks like a victim ("I am about to die"). Then v.34 ends with the narrator's verdict: "So Esau despised his birthright." Single sentence, reframed episode.

**John 2:18–22.** "Destroy this temple and I will raise it again in three days." The bystanders are confused. The narrator clarifies: "But the temple he had spoken of was his body." A massive Christological claim made by the narrator, not directly by Jesus.

### N/A condition

Epistles, wisdom literature, most poetry — these aren't narrative, so the tool doesn't apply.

### Pitfall

Missing the comment because it's tucked into a paragraph and reads like the action. Treating character speech as if it carried the same weight as narrator commentary.
