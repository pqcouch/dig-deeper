# Claim Audit Output Format

Load this file when Claim Audit Mode (SKILL.md Phase 0.5b) is active. Decide the output format **before scoping the audit** — standalone file or embedded verdicts — so the audit is worked toward the right deliverable from the start.

---

## Standalone file vs embedded verdicts

**Produce a standalone claim audit file when:**

- Auditing a book-overview across multiple passages before a series begins
- After a multi-passage sweep where allusion confidence needs to be settled and referenced across later sessions
- When auditing claims from a new secondary source before incorporating them into a book-overview
- When the user explicitly asks for a claim audit document

**Embed instead:** If auditing claims for a single passage as part of its full dig-deeper, record verdicts under the relevant tools (Tool 7, Tool 11) with `[S: audit]` tags. A standalone file is only needed when verdicts will be referenced across multiple sessions.

**Filename:** `dig-deeper-[book]-claim-audit.md`

---

## File structure

````markdown
# Claim Audit: [Book]

**Passages audited:** [List]
**Date:** [Today]
**Purpose:** [What this audit is testing — e.g., "Book-overview allusion claims before the series begins" or "Scacewater discourse-analysis claims before overview update"]

---

## Claims Audited

### Claim 1: [Short label — e.g., "Gen 3:6 verbal echo in 2 Sam 11:2–4"]

**Source:** [Book-overview section and current confidence rating — or external source citation]
**Claim:** [The exact claim being tested]

**Hays criteria:**

| Criterion | Score (Strong / Possible / Weak) | Reasoning |
|-----------|----------------------------------|-----------|
| Availability | | Was this OT text available to the author? |
| Volume | | How much verbal/conceptual overlap? |
| Recurrence | | Does this source appear elsewhere in the book? |
| Thematic Coherence | | Does the allusion fit the passage's argument? |
| Historical Plausibility | | Is the connection historically plausible? |
| History of Interpretation | | Do others see this connection? |
| Satisfaction | | Does positing the allusion illuminate the passage? |

**Verdict:** [Confirmed / Confirmed with nuance / Needs reframing / Uncertain — flag for research / Discard]

**Reasoning:** [1–3 sentences]

**Book-overview action required:** [What changes, if anything — or "None"]

---
[Repeat for each claim]

---

## Summary

| Verdict | Count |
|---------|-------|
| Confirmed | |
| Confirmed with nuance | |
| Needs reframing | |
| Uncertain — flag for research | |
| Discard | |

### Confidence Change Propagation

For every allusion whose confidence was upgraded or downgraded from its book-overview rating, list every section of the book-overview document where the change must be applied. A confidence change recorded in one table but not others creates internal inconsistency and misleads the preacher. See `book-overview/references/quality-checks.md` § Confidence change propagation.

| Allusion | Previous confidence | New confidence | Sections to update |
|----------|--------------------|-----------------|--------------------|
| | | | |

### Recommended book-overview revisions

[Summary of what should be updated. "None required" if the audit confirms the overview throughout.]
````

---

## Consuming this file in subsequent dig-deepers

When a claim audit for the book is present in the conversation, treat it as a checking-stage secondary source at Phase 5.5. Accept verdicts as given, tag findings with `[S: audit]`, and surface any tensions between the audit's verdicts and fresh text-first work. Do not re-derive what it has already tested.
