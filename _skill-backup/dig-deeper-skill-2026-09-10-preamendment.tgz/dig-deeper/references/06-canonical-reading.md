# Tools 11–12: Canonical Reading

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 12–13.

---

## 11. Quotation/Allusion

**The question:** Does this passage quote or allude to earlier Scripture, and if so, what does that add?

**The principle:** Scripture interprets Scripture. NT writers especially saturate their work with OT references, often without flagging them explicitly. Spotting allusions opens up enormous interpretive depth.

### Three types

**Direct quotations** — usually flagged in modern translations with italics, footnotes, or formula ("it is written").

**Verbal allusions** — distinctive phrases that crop up elsewhere. *The more specific or unusual the expression, the less likely a coincidence.*
- "Sheep without a shepherd" (Mark 6:34 ← Num 27:17): distinctive — almost certainly intentional.
- "Sheep" alone: too common to mean anything.

**Conceptual allusions** — themes, motifs, narrative shapes that echo earlier Scripture without verbal match. Exodus motifs, new-creation motifs, Davidic kingship.

### The Abrahamic covenant — a special case

Alluded to so often that it deserves dedicated attention. Three promises (descendants, land, blessing to nations) repeated to Abraham (Gen 12, 13, 15, 17), Isaac (Gen 26:3–4), Jacob (Gen 28:13–14), and echoed throughout Scripture (Exod 2:24; Deut 9:27; 1 Chron 27:23; Gal 3:29). Whenever you see these themes, ask if the Abrahamic covenant is in view.

### Common allusion families to watch for

| Family | Markers | Significance |
|--------|---------|-------------|
| **Creation** | Light/darkness, "let there be", garden imagery, image of God, days, *tohu wabohu* (formless/empty) | Reframes the new act as new creation |
| **Fall** | Eden, serpent, tree, naked, hiding, "did God really say" | Re-enacts or reverses the fall |
| **Flood** | Water/judgment, ark, dove, rainbow | Judgment + remnant + new beginning |
| **Abrahamic covenant** | Descendants/seed, land, blessing to nations, "as numerous as stars/sand" | Promise being progressed or fulfilled |
| **Exodus** | Slavery, redemption, Passover, blood, Red Sea, wilderness, manna, plagues | Salvation pattern; new exodus |
| **Sinai** | Mountain, law, glory cloud, priesthood, tabernacle, "consecrate yourselves" | Covenant/theophany |
| **Davidic** | Anointed one, Son of David, throne, kingdom forever, Zion | Messianic expectation |
| **Temple** | God's dwelling, glory, sacrifice, priest, veil, holy place | Where God meets man |
| **Exile / return** | Babylon, captivity, scattered, return, new exodus, restoration | The not-yet-resolved tension of the OT |
| **Servant** | Suffering servant (Isa 52–53), bearing iniquity, "led like a lamb", numbered with transgressors | Christ's substitutionary death |
| **Day of the LORD** | Judgment, darkness, day of wrath, locusts, destruction, restoration | Eschatological reckoning |
| **Wisdom** | "Where is wisdom found?", tree of life, two ways | Pursuit of life-as-it-should-be |
| **Shepherd** | Lost sheep, gather, lead, pasture, shepherd-king (Ezek 34) | God's care; messianic role |

### What to do

For every passage, check:

1. Does this passage **directly quote** earlier Scripture? (Cross-check footnotes/margin notes.) If so, *go back and read the original context* — the OT setting almost always shapes the NT use. **Critically: don't limit this to the cited verse.** Read what surrounds it in the source text — the narrative or argumentative setting before and after. Ask: what is happening in the source text at the moment of the citation? Who are the figures involved? What has just happened? What follows? The *context of the allusion's source* often carries content that shapes how it functions in the passage you're working on.
2. Are there **verbal echoes** — distinctive phrases? Test by asking: would this phrase occur to anyone *without* the OT background? If not, it's likely deliberate.
3. Are there **conceptual echoes** — story shapes, motifs, narrative beats? E.g., a deliverer raised up from oppressed origins (Moses/David/Jesus); a meal hosted by a divine host (Sinai/Last Supper/Marriage Supper of the Lamb).
   - **Adjacency / narrative-pattern check (run this whenever a source frame is already established nearby).** When a strong source frame has been established in the *immediately surrounding context* — the previous or next pericope, or earlier in the same run of passages — actively ask whether the present passage *completes a known narrative pattern* from that same source, not only whether it shares vocabulary with it. Verbal-echo hunting (step 2) tends to fire first and can crowd out pattern-recognition; a source can be loudly present by narrative shape while leaving few or no distinctive words. *Worked example of the miss this prevents:* if the preceding passage is staged as a Sinai **ascent** (mountain, six days, cloud, glory, voice — Exod 24), then a following scene in which the protagonist **descends into a camp/crowd in chaos** should trigger a check against Exodus 32 (Moses comes down from the glory to find disorder) — even though the second scene may contain no verbal quotation of Exod 32 at all. The warrant for the echo is the established frame next door, plus the matching narrative beat; flag it *moderate* (pattern, not citation) and note the contrast as well as the likeness. Generalise: ascent→descent, exile→return, wilderness-testing, covenant-ratification-then-breach, and similar two-stage OT patterns are frequently split across adjacent NT pericopes.
4. **For OT passages**, what earlier OT does this build on? (Yes — the OT alludes to itself constantly. Psalm 78 to the exodus. Isaiah to creation. The whole prophetic corpus to covenant.)
5. **For theologically loaded titles and terms** (Christ, Son of Man, Son of God, Lord, Servant, the Righteous One, etc.): identify the specific OT text that most directly shapes the meaning of the title *in this particular context*. These titles are often themselves allusions — compressed references to a scriptural figure or passage. Ask: which OT passage is this title indexing right now, and what does that passage's own content (its narrative logic, its figures, what precedes and follows the key verse) add to this passage? Don't stop at defining what the term means in general; ask what specific Scripture it is invoking here.
6. **For significant place names, personal names, and numbers:** ask whether the author is invoking their canonical history — either the first canonical occurrence or a major associated event — rather than (or as well as) the name's etymology. A place name can allude to what happened there; a personal name to the canonical figure who bore it; a number to its founding instance in the canon. This is a form of conceptual allusion that can operate without any verbal quotation and will therefore fail a verbal-echo search entirely. Run the full Tool 7c discipline (proper-noun inventory → three-question check → **load-the-story rule** for load-bearing hyperlinks → **outstanding-word check** for curses, vows, oaths, and prophecies attached to the name → **name-wordplay check**) and report findings here at the appropriate confidence level. An outstanding-word activation (e.g. 1 Kgs 16:34 detonating Josh 6:26) is treated as a high-significance citation and receives Move 1 treatment of the source narrative. *See also:* `04-words-and-translations.md` §Canonical history of names, places, and numbers.

7. **Non-verbal allusion carriers — a weighted catalogue.** Beyond words, names, and narrative beats, the canon hyperlinks through several other carriers. Each is a legitimate allusion type and receives the same confidence weighting as textual allusions (*high / moderate / uncertain*, Hays criteria applying); none may be reported without a stated weight.
   - **Character dossier (recurring figures).** When a person or family recurs across books or pericopes — the sons of Zeruiah, Barzillai, the house of Eli, Caleb, the Rechabites — their *canonical arc to this point* is part of the passage's freight. Build a two-to-four-line dossier: first appearance, defining episode(s), trajectory (rising/falling/faithful/compromised), and what the reader is meant to carry into this scene. The load-the-story rule applies: a dossier for a load-bearing figure must be built from re-read source narrative, not free association. *Weighting:* high where the narrator invokes the history explicitly ("Barzillai the Gileadite, who had provided for the king…", 1 Kgs 2:7); moderate where the arc is well established but uninvoked; uncertain where the identification of the figure itself is disputed.
   - **Route as allusion (itineraries and geography-in-motion).** A journey can retrace an earlier journey, and the retracing is the point: Elijah's forty days to Horeb re-walking Moses (1 Kgs 19 ← Exod 24/34); Jesus' forty days recapitulating Israel's wilderness (Matt 4 ← Deut 8); Abram's Bethel–Negev–Bethel loop replayed by Jacob. Check: does the passage's *sequence of places* (not just any single place) match a canonical precedent in order and direction? Direction matters — up to the mountain vs down to Egypt carries theological charge. *Weighting:* high where multiple waypoints match in sequence plus a corroborating detail (forty days, the same mountain); moderate for a two-point match with thematic fit; uncertain for single-place overlap — which usually belongs under the 7c name check, not here.
   - **Pattern-break absence (the narrow, admissible form of the absence argument).** Arguments from silence are generally inadmissible — an absence that must be *guessed at* is not a finding. But an absence becomes **noticeable rather than guessed** when the text itself has built the expectation it then breaks: a refrain or formula used consistently elsewhere in the book that goes missing here; a stock element of a type-scene omitted (a betrothal scene with no well, a commissioning with no objection); a name systematically expected in the genre yet absent from the whole book (the divine name in Esther — a book-level pattern, not a verse-level guess). **Hard gate:** report an absence only if you can state the *established pattern* that makes the absence visible, citing its instances; if you cannot cite the pattern, the observation is inadmissible and must not appear in the report even as a hedge. *Weighting:* never higher than moderate; book-level absences flagged for commentary verification.

   Findings from any of these carriers that prove load-bearing are cross-reported into Headline Findings with their weight attached, exactly as textual allusions are.

### Confidence flagging is essential

Allusions vary wildly in certainty. Mark explicitly:
- *High confidence:* direct quotation, very distinctive verbal match, or near-universal scholarly agreement.
- *Moderate confidence:* plausible verbal or conceptual echo, but not certain.
- *Uncertain — consider verifying:* a possible echo Claude is reaching for; recommend a commentary or concordance check.

### Intertextual clustering and canonical weighting

**Allusions are not independent probability events.** They cluster. This principle governs how to weight potential allusions in any given passage:

**Step 1 — Establish the book's confirmed live sources.**
Before working Tool 11 on a passage, identify which source texts the book is *already demonstrably in dialogue with* (at least two clear allusions elsewhere in the book). These are the "live sources." Any further echo from a live source has a substantially higher prior probability than a cold allusion from a source with no foothold in the book.

> *Example:* If Ruth is already drawing on Genesis (1:16–17 = covenant pledge; 4:12 = Tamar connection) and Proverbs (3:11 = *ʾēšet ḥayil*), then further Genesis or Proverbs resonances in a given passage are more likely, not less. The author's/editor's mind is already running in that register.

**Step 2 — Apply canonical proximity weighting.**
Books in the same canonical section (Torah / Nevi'im / Writings) share the same canonical neighbourhood. Their readers had them in their ears simultaneously. An allusion to a canonical neighbour deserves an elevated prior compared to an allusion from a different canonical section.

| Canonical section | Neighbours with elevated prior |
|-------------------|-------------------------------|
| **Torah** | Genesis–Deuteronomy are in constant dialogue with each other |
| **Nevi'im** | Earlier prophets interpret each other; Isaiah, Jeremiah, Ezekiel saturate later prophets |
| **Writings** | Job, Psalms, Proverbs, Ecclesiastes, Song of Songs, Lamentations, Ruth, Esther, Daniel, Ezra-Nehemiah, Chronicles — all share the exilic/post-exilic canonical register. *Shaddai* language in the Writings points to Job/Psalms first. Wisdom vocabulary points to Proverbs/Ecclesiastes first. Praise vocabulary points to Psalms first. |

**Step 3 — Note when a cold allusion is still warranted.**
Canonical proximity is a prior, not a veto. A cold allusion (from outside the confirmed live sources and from a different canonical section) may still be the right call if:
- The verbal match is highly distinctive and unusual
- The conceptual echo is structurally load-bearing
- There is scholarly consensus supporting it

Flag cold allusions with *moderate confidence* or lower unless they meet those criteria.

**Practical workflow for the report:**
1. Before working Tool 11, briefly list the book's confirmed live sources (from the book-overview's intertextual map if present, or from prior passages in the series).
2. Work the passage with confirmed live sources at elevated attention.
3. Flag canonical-proximity allusions as elevated prior.
4. Flag cold allusions as requiring distinctive verbal/conceptual match to carry weight.

### Book example (Ezra 3:10–13)

Old priests weep at the laying of the temple foundation while younger ones rejoice. Why the weeping? Allusion to 2 Chron 5:13–14 — same words ("He is good; his love endures forever"), same trumpets and cymbals, but in Chronicles the cloud of God's glory fills the temple. In Ezra, no cloud, no glory. A temple without God's presence is a shell. The allusion is the whole interpretive key.

### Operational guidance for the report

- **For NT passages**, *always* check OT background. The NT writers' Bible was the OT; they're soaking in it.
- **For OT passages**, check earlier OT background and (separately, under Bible Timeline / Christological Reading extension) NT trajectory.
- If a book-overview's intertextual map is in conversation, confirm or extend — and flag if the overview missed something.
- When you find a strong allusion, **state what the original context contributes**. Don't just say "echoes Isaiah 53"; say what Isaiah 53 brings into the passage.
- **Doctrinal-argument follow-through check:** When an allusion connects to a theme that the *letter's own preceding argument* has already developed, do not stop at noting the allusion. Ask: **is this passage the enacted consequence of that argument?** See the full description above.

---

### Independent candidate-finding (before Move 1)

**Do this before applying the triad to any candidate a secondary source named.** Auditing a citation a commentary, lecture transcript, or prior overview already named is *not* Tool 11 — even done rigorously, even while correctly downgrading its confidence. That verse is one candidate, not the search itself; checking only it will systematically miss citations the source never raised.

So derive candidates independently first:

1. Take the passage's own distinctive vocabulary — the actual words, not a paraphrase.
2. Ask where else in the canon that specific wording occurs, **starting with the immediate literary neighbourhood of any named candidate** — the chapter before and after it, not just the cited verse, because the closest vocabulary often sits one chapter over from where the source pointed.
3. Then run the triad on each candidate — your own and the source's.

Independent candidate-finding is cheap; skipping it is the difference between checking a source's homework and doing the search.

### OT Citation Triad *(required for every direct quotation; required for every high-confidence allusion)*

For each significant OT citation, three moves are mandatory. They are distinct and must not be collapsed into one. A finding in Move 1 does not substitute for Move 2 or Move 3.

---

**Move 1 — Source context mini-pass**

*What is the OT passage about in its own right?*

Do not stop at the cited verse. Read the surrounding passage — enough to answer:

- Who is speaking, to whom, and why?
- What is the argument or narrative movement in the surrounding section?
- What has just happened, or been said, immediately before the cited verse?
- What follows immediately after?
- What is the emotional register of the source passage?
- What is the *function* of the cited verse within its own passage — is it a climax, a pivot, a supporting premise, a lament, a verdict?

**Why this matters:** The NT author is rarely quoting a verse in isolation. The verse carries its surrounding context into the new passage. A citation from the middle of a lament brings the lament. A citation from a victory song brings the victory. A citation from a section that deals with judgment followed immediately by restoration brings both.

**Worked example:** Romans 15:3 cites Psalm 69:9b: "The reproaches of those who reproached you fell on me." The cited verse alone says: the psalmist bears reproaches meant for God. The source context mini-pass adds: Psalm 69 is one of the great lament psalms and one of the most heavily cited in the NT passion narratives. It describes the suffering righteous person's isolation, public humiliation, and persecution for God's sake — followed by divine vindication. The verse is not a isolated statement of vicarious suffering; it is from a psalm of *costly, public, passion-shaped* identification with God's cause. This gives Paul's use in Romans 15:3 its full weight: Christ bore not just reproach but the specific shape of passion-lament, as the model for the strong bearing with the weak.

---

**Move 2 — Book usage tracking**

*Has this OT text — or any text from the same OT source — appeared before in this book or series? What did it do there?*

Before recording a finding under Tool 11, check the book-overview's intertextual map (from Phase 0.5) for earlier uses of:
- This specific verse
- Other verses from the same OT chapter
- Other verses from the same OT book

Then ask:

- Is the author tracking this OT source across multiple moments of the argument?
- What did the earlier use establish?
- Does the current use *develop*, *resolve*, *reverse*, or *confirm* the earlier use?
- Is the author following the OT source's own internal movement — citing it at stage A earlier in the book and at stage B later, where A and B are sequential within the OT source?

**Why this matters:** Authors don't dip into OT sources randomly. When an author returns to the same OT source at multiple points, they are usually following that source's own internal logic. The pattern of citations reveals the author's sustained conversation partner. Missing it means missing the argument's backbone.

**Phrase-level check for image-dense passages.** Confirming a *theme* (new exodus, kingship, exile-and-return) is live in the book using one or two representative touchpoints does **not** satisfy Move 2. Theme-level and phrase-level checks are different operations: a passage can pass the first while still hiding near-verbatim self-quotations of earlier material at the phrase level. **Trigger: if the passage names five or more distinct concrete things (places, objects, peoples, numbers), run Move 2 per image** — check each separately against the rest of the book before concluding Move 2 is complete. This is exactly the bulk phrase-matching a concordance or cross-reference tool does well (see "Handling Tools That Need External Data" in SKILL.md).

**Worked example — Deuteronomy 32 in Romans:**
- 10:19 — Deut 32:21: "I will make you jealous of those who are not a nation" — the jealousy provocation
- 12:19 — Deut 32:35: "Vengeance is mine, I will repay" — the non-retaliation ethic
- 15:10 — Deut 32:43 LXX: "Rejoice, O Gentiles, with his people" — the worship resolution

Book usage tracking reveals: Paul is following Deuteronomy 32's own internal arc. The Song of Moses moves from provocation (32:21) through judgment/vengeance (32:35) to final joint worship (32:43). Paul follows that exact sequence across Romans 10–15. He is not proof-texting; he is tracing Moses' song to its destination. Without book usage tracking, three separate citations look like three proof-texts. With it, they look like one sustained argument from one OT source, and the whole arc of Romans 10–15 becomes visible.

---

**Move 3 — OT-to-OT relational check**

*Do the OT texts cited in this same NT passage already talk to each other in the OT? Is the NT author exploiting a pre-existing canonical conversation?*

When a NT passage cites multiple OT sources within a short span, ask for each pairing:

- Are these OT texts from the same canonical section (Torah/Nevi'im/Writings)?
- Do these OT texts address the same theme, figure, or event in their own contexts?
- Does one OT text explicitly cite or echo the other?
- Were these OT texts already in canonical conversation before the NT author reached them?
- Is the NT author *importing a pre-existing OT argument* — one whose logic the original audience would have recognised — rather than constructing a fresh argument from isolated proof-texts?

Also ask: does a single OT passage cited in this NT passage *already contain* an OT-to-OT allusion — so that citing it activates not just its own content but the earlier OT it was itself reworking?

**Why this matters:** The NT authors were not the first to put these texts in conversation. Isaiah reworks the exodus. Deuteronomy 32 reworks Genesis. The Psalms meditate on the Torah. Prophets interpret earlier prophets. A NT author citing two texts already in canonical dialogue is not creating a new connection — they are pointing to one that already existed and relying on the audience to hear it. Missing the pre-existing OT connection means missing half the argument.

**Worked example — Romans 15:9-12 catena:**

The four citations are: Psalm 18:49 (David praising among Gentiles), Deuteronomy 32:43 (Gentiles rejoicing with Israel), Psalm 117:1 (all nations praising the Lord), Isaiah 11:10 (Gentiles hoping in the Root of Jesse).

OT-to-OT relational check:

*Psalm 18 and Deuteronomy 32:* Psalm 18 is a Davidic psalm of deliverance and royal triumph. The Psalter's royal psalms consistently draw on Deuteronomy's covenant framework — the king who obeys Torah is delivered and rules the nations. Psalm 18's "I will praise you among the nations" is within the Deuteronomic covenant logic of blessing-through-obedience. When Paul pairs it with Deuteronomy 32:43, he is pairing two texts from the same theological tradition, already in conversation.

*Deuteronomy 32 and Isaiah 11:* Isaiah's vision of the shoot of Jesse (Isa 11) and Deuteronomy 32's nations-joining-Israel scene (32:43) are thematically parallel: both describe the eschatological gathering of Gentiles around Israel's king. Isaiah may be deliberately developing the Deuteronomy 32 vision — the Servant Songs in Isaiah are heavily shaped by the Mosaic servant-figure of Deuteronomy. The nations coming to the Root of Jesse (Isa 11) and the nations rejoicing with Israel (Deut 32:43) are not two independent texts Paul has found — they may already be in dialogue within the OT's own eschatological vision.

*The canonical completeness structure:* The catena draws from Writings (Ps 18), Torah (Deut 32), Writings (Ps 117), Prophets (Isa 11) — one from each major canonical division. This is the same move as in 3:10-18. Paul is demonstrating that the Gentile-worship theme is not the property of one OT section; it is the unified OT witness. The structure of the catena is itself an OT-to-OT argument: Torah, Prophets, and Writings all speak the same word.

---

**Move 4 — Internal echo check** *(required for every passage, whether or not it contains an OT citation)*

*Does this passage answer, invert, fulfil, or ironically echo something raised earlier in this same book?*

Moves 1–3 look outward to external OT sources; Move 4 looks inward. It is a **per-passage** check, not a per-citation one, and it is required even when Tool 11 has no external citations to work — a passage with no OT quotations can still be the answer to a question its own book raised ten chapters earlier.

Ask, deliberately:

- Does anything in this passage resolve, judge, reward, or reverse something an *earlier* passage in this book set up — a boast, a promise, a threat, a named group, an unanswered question?
- Conversely, does this passage *plant* something (a warning, a named party, a distinctive image or phrase) that the book plausibly returns to later? Flag it forward: `Internal: [planted — watch for resolution]`.
- **Always hold the book's opening unit(s) open while asking.** Openings are the densest planting ground in Scripture and the most commonly forgotten by the time the exegete reaches the book's climax. For any passage in the book's second half, explicitly re-read the opening chapters' distinctive material against the current passage before concluding Move 4 is empty.
- **Addressee-differentiation:** if the book opens by naming several distinct parties (the seven churches, Jacob's twelve sons, Job's three friends), ask whether the current passage individually resolves, judges, or fulfils *one of them specifically*. Differentiated openings receive differentiated resolutions, usually many chapters away and usually without verbal flag-waving.

**The trap this move exists for:** quiet echoes. Explicit bookends, matched refrains, and direct narrative continuations announce themselves and will be caught anyway. The echoes that get missed are the unadvertised ones — Laodicea's "I am rich, I have prospered, I need nothing" (Rev 3:17) answered by Babylon's "I sit as a queen... I will never see mourning" (Rev 18:7); the Nicolaitans' compromise in Ephesus anticipating the beast's economy. Nothing in a source-hunting method surfaces these, because they involve no external source. You only see them by holding two passages of the same book side by side and asking the question — which is precisely what this move instructs.

**Report format:** record findings under Tool 11 with the `Internal:` prefix, direction marked (*answers §earlier* / *planted for later*), confidence flagged as usual, and a one-line "what it adds". Internal echo findings are prime input for the book-overview's early↔late structural echo table — tag them clearly so a later finalise pass (`book-overview` Finalise mode, Stage 2) can harvest them without re-reading every report in full.

If the check genuinely turns up nothing, say so in one line ("Internal: none found; opening material checked") rather than omitting the move — the explicit nil-return is what distinguishes a run check from a skipped one.

---

**Report format for OT citations:**

Present each significant citation as a named unit with all three moves:

```markdown
**[OT reference] → [NT verse]** *(confidence level)*

*Source context:* [What the OT passage is about in its own right; what surrounds the cited verse; what the verse's function is within its own passage]

*Book usage:* [Whether this OT source has appeared earlier in this book/series; what it did there; whether the author is following the OT source's own internal movement]

*OT-to-OT:* [Whether this OT text is already in canonical conversation with other OT texts cited nearby in this NT passage; what that pre-existing conversation contributes]

*What it adds:* [What the full triad — source context + book usage + OT-to-OT — contributes to the passage being exegeted]
```

For a minor allusion (moderate confidence, supporting rather than load-bearing), Move 1 alone is sufficient; note "Book usage: not applicable / no earlier use" and "OT-to-OT: no pairing in this passage." Do not pad.

---

### Pitfall

Seeing allusions where none exist. Missing them because they're not flagged. **Stopping at Move 1 (source context) without asking whether the book has used this OT source before (Move 2) or whether this OT text is already in conversation with other citations in the same NT passage (Move 3) — or skipping Move 4 (internal echo) because the passage has no external citations, when internal echo is exactly the check that needs no citation to run.** The moves are not optional extras — they are the difference between treating the OT as a quarry of isolated proof-texts and reading it as a coherent canon that NT authors engaged with as a whole.

Also: **missing name-, place-, and number-based allusions because they carry no verbal overlap.** A place name invoking an event (Shiloh = glory departed), or a personal name echoing a canonical figure (Saul = the rejected king), leaves no distinctive quoted phrase and will not surface in a verbal-echo search. Run Tool 7c's canonical-history check as a separate discipline.

> **See also:** `extensions/biblical-theology.md` for systematic tracing of themes. **See also:** Tool 2 (Context) Positional Necessity Check — required for every passage in every genre; the Positional Necessity Check and the OT Citation Triad are designed to interlock, since Move 2 (book usage tracking) feeds directly into the Positional Necessity Check's doctrinal-prediction question. The step 3 *adjacency / narrative-pattern check* feeds the same place from the other direction: when a passage completes a two-stage OT pattern begun in an adjacent pericope, that completion is often the answer to *why this passage exists here*.

---

## 12. Genre

**The question:** What kind of literature is this, and what reading rules apply?

**The principle:** Genre determines interpretation. "I am poured out like water" (Ps 22) is poetry, not biology. The empty tomb is history, not metaphor. Identify the genre first.

### Two general principles

1. **When something is presented as historical fact, pause to consider that it really happened.** Even miracles. Especially miracles. They're "signs" pointing beyond themselves, but they're still real.
2. **When something is presented as imagery/metaphor, don't base predictions on it being literally true.** "Vision not Video" (John Richardson on Revelation). Revelation is not a documentary.

### Bible genres

| Genre | Examples | Reading rules |
|-------|----------|---------------|
| **Historical narrative** | Gen 12–50, Exodus, Joshua, Samuel, Kings, Chronicles, Ezra-Nehemiah, Gospels, Acts | Happened. Theologically loaded. Use Narrator's Comment, Copycat. |
| **Law** | Most of Exodus, Leviticus, Numbers, Deuteronomy | God's covenant terms. Apply via Bible Timeline — much fulfilled in Christ. |
| **Poetry — lament** | Many Psalms, Lamentations, parts of Job | Permission to grieve; don't resolve too fast. |
| **Poetry — praise** | Many Psalms, songs in narrative (Exod 15, Luke 1) | Doxological; invite the reader to join. |
| **Poetry — wisdom** | Job (mostly), parts of Psalms | Wrestling with how the world works. |
| **Wisdom — proverb** | Proverbs | Generally-true observations. Not promises. |
| **Wisdom — reflection** | Ecclesiastes | "Under the sun" perspective; needs the whole-book lens. |
| **Prophecy** | Isaiah–Malachi (mixed with narrative/poetry) | Originally spoken to specific situations; often double-horizon (near and far). |
| **Apocalyptic** | Daniel 7–12, Zechariah (parts), Revelation, Ezekiel (visions), Mark 13 / Matt 24 / Luke 21 | Vision-language. Symbolic numbers, beasts, etc. Vision not video. |
| **Parable** | Many in Synoptic Gospels | Comparison stories; one main point usually; don't allegorise every detail. |
| **Epistle (letter)** | Romans–Jude | Sustained argument, real situations, real audiences. Read for the flow. |
| **Gospel** | Matthew–John | Historical narrative + theological commentary + Christological focus. |
| **Genealogy** | Gen 5, 10, 11; 1 Chron 1–9; Matt 1; Luke 3 | Theological architecture, not just data — note who's in, who's out, what's emphasised. |
| **Sermon / speech embedded in narrative** | Acts speeches, Deuteronomy (Moses' speeches), Joshua 24 | Sermon analysed within its narrative setting. |

*The three "Poetry —" rows name reading-rules for kinds of poetry across the canon (Lamentations, Job, the songs embedded in narrative); within the Psalter they are **not** a form-critical grid for sorting individual psalms — see "The Psalter" below.*

### Numbers in apocalyptic

Often symbolic. 144,000 in Rev 7 = 12 × 12 × 1000 — completeness × completeness × a huge number — meaning *a vast number from the people of God*. Not literal.

### Mixed genres

Many passages mix genres. A Gospel has narrative + parable + discourse + dialogue + apocalyptic prediction. A prophetic book has poetic oracle + narrative report + vision + dialogue. Identify the **specific genre of the passage you're working on**, not just the book's overall genre.

### The Psalter — genre vs form-critical classification

Two different things get called "genre," and the tool must not conflate them:

1. **The literary kind of a book or large sub-unit** — poetry, law, gospel, letter, apocalyptic, and so on. *This* is what the Genre tool classifies, and for the Psalms the answer is **Hebrew poetry**, naming where it helps the sub-collection's own canonical shape (e.g. "a Song of Ascents collection within Book V", "a Korahite group", "the acrostic of Ps 119").
2. **The form-critical *Gattung* of an individual psalm** — lament, hymn, thanksgiving, royal, individual/communal, entrance liturgy, and the rest of the Gunkel–Mowinckel taxonomy. **The Genre tool does not deploy this system.** Do not sort the psalms into these categories, and do not build the reading on them.

**Why.** With Hely-Hutchinson, the Psalter's theological coherence and messianic trajectory take priority over the categorical frameworks Gunkel and Mowinckel established; genre analysis is secondary to how the editors shaped the collection to answer the "psalmist's perplexity" — the tension between God's promises and historical experience — through the lens of new-covenant fulfilment. Form criticism reads a psalm outward to a *reconstructed cultic setting* — history-behind-the-text, exactly the move the Text-First Discipline flags. The shaping the text actually bears is editorial and canonical, so route that work to Tool 2's Positional Necessity Check (where does this psalm sit in the Psalter's arc, and why here?), Tool 11 (Quotation/Allusion), the biblical-theology extension, and the Christological reading — never to a *Gattung* label.

**What stays.** The *reading rules* poetry carries are still in force — lament gives permission to grieve and does not resolve too fast; praise is doxological and invites the reader in. Describe from the text what a given psalm *does* (it grieves, it pleads, it summons praise, it blesses) as observation; simply do not convert that observation into a form-critical *classification* of the psalm. The distinction is between reading the poetry and cataloguing the psalm.

### Book example (Genesis 1)

The "days" of Gen 1 are genuinely contested — literal 24-hour days, or ordered-poetic structure of creation. The book is honest that genre isn't always obvious. Where genre is contested, name the options and note what each interpretive choice would imply.

### Operational guidance for the report

- For most passages, this section is brief — "Hebrew narrative" or "Pauline argument" plus a sentence on reading rules. Don't pad.
- For passages where genre is unusual or contested (apocalyptic, parable, deliberate genre-mixing), spell out the implications.
- Flag if the passage contains a sub-genre embedded in a host genre (a song inside a narrative; a parable inside a sermon).
- **In the Psalter, classify at the book/collection level only** — "Hebrew poetry", plus the sub-collection's canonical shape. Do **not** assign Gunkel–Mowinckel form-critical labels (lament / hymn / thanksgiving / royal…) to individual psalms; hand the shaping question to Tool 2 (Positional Necessity), Tool 11, and the biblical-theology / Christological extensions (see "The Psalter" above).

### Pitfall

Reading parable as history (the sower's seed isn't agricultural advice). Reading apocalyptic as documentary (heavenly cities don't wear wedding dresses). Reading wisdom as promise ("the wicked won't prosper" — except sometimes they do; Proverbs is generalisations). Flattening lament into reassurance. Importing the form-critical *Gattung* taxonomy into the Psalms — treating the classification of a psalm as a "lament" or "hymn" as though *that* were the interpretive payoff — which flattens the editorial shaping and messianic trajectory that actually carry the Psalter's meaning.
