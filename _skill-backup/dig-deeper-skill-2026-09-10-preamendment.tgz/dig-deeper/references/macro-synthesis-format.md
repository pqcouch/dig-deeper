# Macro-Synthesis Output Format

Load this file when Macro-Synthesis Mode (SKILL.md Phase 0.5c) is active. Decide the output format **before scanning the runs** — standalone file plus a condensed book-overview section — so the synthesis is worked toward the right deliverable from the start.

Macro-Synthesis Mode is the toolkit turned *sideways*. Fresh Exegesis works one passage down through the sixteen tools; a claim audit tests named claims; Macro-Synthesis reads *across* a completed (or near-completed) set of dig-deeper runs for the patterns that no single run could establish. Its raw material is not the biblical text directly but the **Convergent Findings** and **Book-Overview Tensions** sections the runs have already produced — so it can only be run once those runs exist.

---

## When to run (prerequisites)

Run Macro-Synthesis Mode only when **all, or nearly all, pericopes of a book have full solo dig-deeper runs in hand** (a single missing Standard-weight pericope is acceptable; a missing HIGH-weight one is not — finish it first). Typical triggers:

- The user asks "what do all these runs add up to?", "what wider arguments emerge across the book?", "pull the threads together", or "what does the sweep show as a whole".
- A book's dig-deeper sweep has just been completed and the lessons should be consolidated before the series is preached.
- A book-overview is being brought to final form and wants a cumulative-case section.

**Do not run it early.** A synthesis built on three or four runs will manufacture patterns from too little evidence (see Guardrails). If the sweep is incomplete, say so and either finish it or scope the synthesis explicitly to the runs in hand, flagged as provisional.

---

## Deliverables

Macro-Synthesis Mode produces **two** linked outputs:

1. **A standalone synthesis file** — `[book]-dig-deeper-macro-synthesis.md` — the evidence-linked long form (one section per macro-argument, with anchor pericopes, verse evidence, confidence, and preaching payoff).
2. **A condensed section patched back into the book-overview** — a "Cross-Pericope Macro-Arguments" section (a table of the arguments with anchor pericopes and confidence, plus a short "for the series as a whole" paragraph), pointing to the standalone file for the long form.

Always produce both: the standalone file is the working artefact; the overview section is how the synthesis reaches the preacher in the living document. Apply the overview patch with the same discipline as any other (copy to working dir, `str_replace`, colophon bump, provenance tag — see `book-overview/references/`).

**Filename:** `[book]-dig-deeper-macro-synthesis.md` (e.g. `genesis-dig-deeper-macro-synthesis.md`).

---

## Method

1. **Gather the runs.** List every dig-deeper run for the book and confirm coverage. Note any gaps and their weight.
2. **Mine the right sections.** For each run, read its **Convergent Findings**, **Book-Overview Tensions**, **Headline Findings**, and **Christological Reading** — these are where a run records what it found load-bearing. Do *not* re-work the sixteen tools; the runs have done that.
3. **Cluster across pericopes by category.** Sort recurring observations into the pattern-categories below. A pattern qualifies as a *macro-argument* only when it recurs across **≥3 pericopes** (or is NT-authorised across ≥2). One-pericope or one-source "patterns" are not macro — list them, if at all, as *candidate threads* flagged "not yet macro".
4. **Rank confidence** with the same discipline as the rest of the toolkit: **NT-authorised** links (a NT text cites or fulfils the chain) = **high**; **converging text-first** findings reached independently in several runs = **strong**; real but looser trajectories = **moderate**. Carry the runs' own `[T]`/`[I]`/`[S]` warrant tags into the evidence lines.
5. **Write the long form**, then **condense** it into the overview-section table.
6. **Patch the overview** and bump its colophon.

### Pattern-category checklist (book-agnostic)

Scan for each; not every book yields every category.

| Category | What you are looking for |
|----------|--------------------------|
| **Diction-driven structure** | a rare/distinctive word or pun repeated across a seam that proves a unit is *placed*, not inserted (a "verbal weld"); puns welding name/place/act |
| **Vocabulary threads** | a single word or motif developing across the whole book (a keyword that climbs from one pericope to another, gaining theological weight) |
| **Distributed interpretive keys** | a thesis stated late but *seeded* earlier — a sentence the book has been arguing before it says it outright |
| **Originated theological programmes** | a theme the book *launches* that the canon completes (presence, seed, kingdom, temple, covenant, exodus) — traceable as a chain to a NT fulfilment |
| **Bookend / inclusio reversals** | structural framing where a later movement answers or reverses an earlier one (macro-section antithesis; opening/closing inclusios) |
| **Recurring narrative motifs** | election patterns, measure-for-measure justice, descent-before-exaltation, type-scenes — motifs that recur as *structure*, not decoration |
| **Christological / applicational method** | the recurring traps the runs refused ("be like X"), and the consistent confidence-ranking of NT-authorised over preacher-constructed typology — the method the sweep embodies |
| **Epistemic / methodological** | what *kind* of evidence proved load-bearing across the runs (e.g. Hebrew diction over source-criticism; single-source superlatives needing refinement) — the sweep as a vindication (or correction) of method |

---

## File structure

````markdown
# [Book] — Dig-Deeper Macro-Synthesis

*What the [n] full solo `/dig-deeper` runs (§1–§[n]), taken together, demonstrate about the book — the cross-pericope arguments invisible at the level of a single passage but unmistakable once the whole sweep is laid side by side. Companion to the [Book] Book Overview (v[x]) and the [book] dig-deeper reports. Text-first; confidence-flagged.*

## How to read this document
[One paragraph: each macro-argument recurs across multiple pericopes; these are emergent, not imposed; confidence key — NT-authorised = high, converging text-first = strong, looser trajectory = moderate.]

---

## [n]. [Macro-argument title]

**Claim.** [One or two sentences.]

**Converging evidence.**
- [evidence with pericope/verse] (§x.) `[T]`/`[I]`/`[S]`
- [evidence with pericope/verse] (§y.)
- [≥3 pericopes, or ≥2 NT-authorised]

**Confidence: [high / strong / moderate]** ([one-line reason]).

**Payoff.** [What it means for preaching/the series.]

---
[Repeat for each macro-argument]

---

## Cross-reference: where each argument is anchored

| # | Macro-argument | Anchor pericopes | Confidence |
|---|----------------|------------------|------------|
| | | | |

---

## What this means for the series as a whole
[One paragraph drawing the arguments into a single cumulative case.]

---

*Provenance: emergent from the [n] dig-deeper runs and reconciled with the [Book] Book Overview (v[x]) and any claim audit. NT-authorised links marked high, converging text-first findings strong, looser trajectories moderate. Offered as connective tissue for the series, not as a replacement for the passage-level runs.*
````

---

## Condensed book-overview section template

Patch this into the book-overview (a sensible home is alongside the book-level insight/"what preachers miss" material). Keep it to the table plus one paragraph; the long form lives in the standalone file.

````markdown
## CROSS-PERICOPE MACRO-ARGUMENTS

*[n] arguments that no single pericope establishes but the full `/dig-deeper` sweep jointly demonstrates — the connective tissue of the series. Condensed here; the evidence-linked long form is `[book]-dig-deeper-macro-synthesis.md`. NT-authorised = high; converging text-first = strong; looser trajectory = moderate.*

| # | Argument | Anchor pericopes | Confidence |
|---|----------|------------------|------------|
| 1 | **[Title].** [one-line statement with the key verse welds] | §x, §y, §z | strong |
| … | | | |

**For the series as a whole:** [one paragraph — the cumulative case.]
````

---

## Guardrails — the Macro-Synthesis failure pattern to avoid

**Manufacturing patterns.** The characteristic failure of a synthesis step is finding tidy patterns that are not really there — imposing a thematic grid on the runs rather than letting it emerge from them. The discipline that prevents this:

- **The ≥3-pericope threshold is a hard gate.** A "thread" resting on one pericope, or on one secondary source, is not a macro-argument. List it as a candidate, flagged "not yet macro", or omit it.
- **Carry the runs' warrant tags forward honestly.** If a chain is `[S]` in the runs (supplied by a source, not text-first), it is `[S]` in the synthesis; do not launder it into a confident pattern. NT-authorised links earn "high"; everything else earns "strong" or "moderate" on the evidence, not on how satisfying the pattern feels.
- **Emergent, not retrofitted.** The synthesis describes what the runs *found*, not what you wish the book argued. If a category yields nothing for this book, say so and move on — an honest "this book does not do X" is a finding.
- **Do not re-exegete.** Macro-Synthesis consumes the runs' conclusions; it does not re-open the sixteen tools. If a run's finding looks wrong, that is a signal to re-run *that pericope*, not to overrule it in the synthesis.
- **Surface what the sweep missed.** As with Claim Audit Mode, a connection the runs *individually* noted but never drew together is exactly what this mode exists to catch — but the catch must still clear the ≥3-pericope gate.

---

## Consuming this file in subsequent work

The standalone synthesis is a checking-stage and planning resource, not a substrate. When preparing an individual sermon later, a passage's own dig-deeper run governs; the synthesis supplies the series-long threads that sermon should serve. When upgrading the book-overview, the synthesis is the source for the Cross-Pericope Macro-Arguments section. Re-run the synthesis (bumping its date) if further pericope runs are added or materially revised.
