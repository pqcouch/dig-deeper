# Tools 9–10: Tone and Repetition

Distilled from Beynon & Sach, *Dig Deeper* (IVP, 2005), chapters 10–11.

---

## 9. Tone and Feel

**The question:** What is the emotional register, and how does the author achieve it?

**The principle:** "There is more to language than just conveying statements of fact." Bible writers don't only inform; they paint, move, persuade. Pay attention not just to *what* is said but *how* it's said and *how it makes you feel*.

**C. S. Lewis's rule** (quoted by Beynon & Sach): "Instead of telling us a thing is 'terrible', describe it so that we'll be terrified. Don't say 'it was a delight', make us say 'delightful' when we've read the description."

### Tonal registers to watch for

| Register | Markers | Examples |
|----------|---------|----------|
| **Lament** | Tears, questions, "how long?", "why?", broken syntax | Ps 88; Lamentations; Job 3 |
| **Celebration** | Imperatives to sing/rejoice, instruments, expanding scope | Ps 33; Ps 98; Luke 1:46–55 |
| **Awe / wonder** | Cosmic imagery, the sublime, silence | Job 38–41; Isa 6; Rev 4–5 |
| **Anger / indignation** | Sharp imperatives, repeated woes, rhetorical questions | Isa 5; Matt 23; Gal 1 |
| **Tender pastoral** | Direct address, gentleness, "my children", repeated assurance | 1 John; Ps 23; John 14 |
| **Satire / mockery** | Ridicule of idols, pomp deflated, ironic understatement | Isa 44; Dan 3; 1 Kings 18:27 |
| **Urgency** | Short sentences, repeated "now", "today", imperatives stacked | 2 Tim 4; Heb 3:7–13 |
| **Despair / dread** | "Doom", "darkness", apocalyptic imagery | Ezek 7; Joel 2; Amos 5 |
| **Joy / exuberance** | Stacked imperatives, instruments, cosmic participation | Isa 55:12; Ps 96 |
| **Grief** | Repetition, broken cadence, "alas" | 2 Sam 18:33 ("O my son Absalom!") |

### What carries the tone

| Device | Effect |
|--------|--------|
| **Detail accumulation** | Small specifics that make scenes three-dimensional |
| **Simile / metaphor** | Comparing to something concrete to evoke feeling |
| **Pacing** | Slowing down or speeding up; short vs long sentences |
| **Direct address** | Switches from "they" to "you" personalise |
| **Questions** | Rhetorical, anguished, accusatory, longing |
| **Repetition** | Drumbeat effect (Repetition tool overlaps here) |
| **Sensory imagery** | Sight, sound, smell, touch evoking presence |
| **Exclamation** | "How long!", "Behold!", "Alas!" |
| **Hyperbole** | "Tears my food day and night" — emotional truth, not literal |

### What to do

- **Narrative:** Look for the small details that bring scenes alive. Where does the author slow down, add colour, sketch character circumstance? Mark's detail in 5:25–34 about the woman who'd "spent all she had" on doctors and only got worse — that's there so we feel her desperation.
- **Poetry:** Look for simile and metaphor. *"As the deer pants for streams of water, so my soul pants for you"* (Ps 42) — a single image conveying desperation more powerfully than any clinical statement.
- **Ask:** What soundtrack would this passage have? A solo violin? A trumpet fanfare? Louis Armstrong? Silence?

### Operational guidance for the report

- Name the dominant tonal register(s) early.
- List the specific devices that establish it.
- Note tonal shifts within the passage — they're usually structurally significant.
- Where the tone is dark, lamenting, or angry, note this for the preacher: the sermon's emotional architecture should honour the text's. **Don't preach a lament cheerfully.**

### Book example (Hosea 1–3)

God commands Hosea, "Marry a whore." Stripped to a sentence, it's still shocking. Hosea acts it out — the marriage, children named "Not-my-loved-one", later the command to take her back. The tone (anguish, scandal, then unfathomable mercy) *is* the theology: this is what spiritual adultery against God looks like, and this is the crazy persistent love with which he loves us anyway.

### Pitfall

Reading the Bible as propositional statements without engaging emotionally. Flattening lament into reassurance, or anger into instruction. Missing the satire and so making a fool of Baal-worship seem dignified.

---

## 10. Repetition

**The question:** What words, phrases, or ideas does the author repeat, and what is he hammering home?

**The principle:** If the author says it more than once, he wants you to notice. Repetition is often the heart of the passage.

### Two kinds

**(a) Repeated words/phrases.** Use coloured pencils — different colour for each repeated feature.

Book example (John 6:47–59): "Life," "live," "living," "die" are repeated relentlessly. So is "came down from heaven" (3x). The thrust: Jesus came down from heaven to give eternal life.

Book example (Daniel 3:1–7): Nebuchadnezzar's statue is "set up" five times — mocking that this god is something a king has put up. Civil-service ranks listed 3x. Musical instruments 4x. The whole pompous affair is being satirised.

**(b) Repeated ideas (different words, same concept).**

Book example (Mark 15:37–46): "Breathed his last" / "already dead" / "had already died" / "body" (corpse) / "tomb" — six different ways of saying Jesus really died. Mark hammering home.

Book example (2 Tim 2:3–6): Soldier (battle then commendation), athlete (training then crown), farmer (work then harvest). Three different pictures, one common idea: suffering now, glory later.

### Repetition and other tools

Repetition combines powerfully with:

| Combined with | Effect |
|---------------|--------|
| **Author's Purpose** | Repeated themes usually = the author's main concerns |
| **Structure** | Repeated phrases often mark section boundaries (e.g., the four "and the people did" refrains in Judges) |
| **Vocabulary** | A repeated big-Bible-word tells you what category the author is working in |
| **Quotation/Allusion** | Repeated OT phrases may all be alluding to the same source |
| **Tone & Feel** | Repetition is itself a tonal device (drumbeat, lament refrain, mounting urgency) |

### Operational guidance for the report

- For passages with strong repetition: list every repeated feature, count occurrences, note position.
- Distinguish word-level repetition from idea-level repetition.
- Note **near-repetition** that isn't quite repetition — small variations in repeated phrases can be deliberate.
- Watch for repetition across longer arcs that book-level work has flagged (book-overview's microscript and vocabulary plan).

### Book caveat

Repetition is a strong signal, not a sole one. Rev 18 repeats "Woe! Woe, O great city" three times — but doesn't tell you whether to mourn or rejoice over Babylon's fall. Context (Rev 19:1–3, where heaven rejoices) settles it.

### Pitfall

Treating repetition as the only key. Counting words mechanically without asking why they're repeated. Missing repetition because the translation has varied the English wording.
