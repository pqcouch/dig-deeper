# Extension: Original Audience Reception

What would the first hearers have understood that we miss? What would have struck them as surprising, shocking, comforting, or familiar? What assumptions did they bring that we don't, and which do we bring that they didn't?

The Historical Background extension surfaces *facts*. This extension surfaces *reception* — the emotional, conceptual, and rhetorical impact on the original hearers.

---

## Why this matters

Many passages were designed to do specific things to specific hearers in specific situations. When we read them now, we hear different things — sometimes losing the original force, sometimes gaining new resonances.

Examples of what original-audience work surfaces:

- **The shock value** that has worn off (Jesus touching a leper; Samaritan as the hero of the parable; women as first resurrection witnesses)
- **The familiar conventions** the author was bending (a king's son riding a donkey; a Messiah who suffers; a religion that includes Gentiles)
- **The political weight** that we miss (calling Jesus "Lord" when Caesar was *kyrios*; "kingdom of God" in occupied territory)
- **The covenantal expectations** that the author assumed (every Jewish reader assumed certain things about Messiah, temple, exile that NT writers play with)
- **The literary conventions** the author was using (type-scenes, rhetorical figures, common genres)

---

## What to ask

### Canonical placement first: who is the *canonical* reader?

Before asking about the original audience in the historical sense, ask about the canonical audience — the reader implied by the book's final form and its position in the Hebrew canon (or NT canon). This is often the theologically normative audience for interpretation.

**Three audiences to distinguish:**

| Audience | Who they are | When to prioritise |
|----------|--------------|--------------------|
| **Narrative world audience** | The implied audience inside the story's world (e.g., Israelites in the judges era for Ruth) | Rarely the primary audience; shapes the story's internal logic |
| **Compositional audience** | Those who first received the text as a shaped literary work | Useful when composition setting is clearly datable (e.g., a letter to a named church) |
| **Canonical audience** | Readers of the book in its canonical location, who know everything before it in the canon | The theologically normative audience; use this for interpretation |

**The canonical audience is the right default.** When in doubt, ask: *what does the reader know who has arrived at this book having read everything before it in the canon?*

**Determining the canonical audience by section:**

| Section | Who the canonical reader is | What they know |
|---------|----------------------------|----------------|
| **Torah** | Readers of the founding story | Creation, fall, flood, patriarchs, exodus, covenant — the entire foundation |
| **Nevi'im (Prophets)** | Readers who know Torah | The Torah + conquest, monarchy, divided kingdom, exile; the prophets are in conversation with all of it |
| **Ketuvim (Writings)** | Readers who know Torah and the full Prophets | Everything the Nevi'im knows, plus: the Nevi'im *ends with Malachi*, which is post-exilic. The canonical reader of the Writings therefore arrives **exilic/post-exilic** — living with the unresolved tension between God's promises and present reality (exile ended but not fully resolved; no Davidic king reigning; the full glory of the LORD not yet returned). |

> **Warrant for the Writings horizon:** The Nevi'im section closes with Malachi — post-exilic, temple worship restored but covenant faithfulness still lacking, awaiting the messenger of the LORD. The Writings are read *after* that. This isn't a guess about dating; it is the logic of the canonical sequence itself. Canonical readers of the Writings know David (and his line), know the exile, know that God's promises are not yet fully resolved.

**Implication for intertextual allusions:** The canonical reader of the Writings has Job, Psalms, and Proverbs in their ears as *canonical neighbours*. Allusions to those books are not accidental resonances — they are reading within the same canonical register. See Tool 11 (Quotation/Allusion) for the clustering principle.

**Special case — Torah passages (Genesis through Deuteronomy):**

For any passage within the Torah, the canonical audience has a distinctive feature that must be held explicitly in view: **the original readers held the creation account and the tabernacle/cult simultaneously**. Israel in the wilderness received Genesis with the tabernacle physically present in their camp. This means:

- Vocabulary that later readers import as "theological background" (the priestly terms *abad/shamar*, the Hithpael of *halak*, the seven-speech structure) is the *native reading frame* the author built in for readers already inhabiting the cult.
- The creation account is not read against a blank cosmological canvas; it is read against the tabernacle the congregation already knows. Eden and the tabernacle illuminate each other *for the original readers* — not retrospectively for later readers.
- This mutual-illumination relationship between Genesis and Exodus–Numbers–Leviticus is not the standard source/reception dynamic (where later books receive earlier ones). It is a fourth category: **intra-Pentateuchal mutual illumination within one authorial work for one audience**. Both directions of illumination are live simultaneously.

**Priority for Torah — no exception to the canonical default:** for the Torah, the compositional audience and the canonical audience *coincide* — wilderness Israel, tabernacle present, is precisely the reader the founding story's final form implies. There is no choice to make between the two lenses; the cult-context reading **is** the canonical reading for these books. Do not treat the tabernacle frame as a compositional-historical alternative to the canonical audience — it is what the canonical audience of the Torah brings.

When working a Torah passage, the "What the original audience knew" section should include this cult-context explicitly — not as background archaeology but as the reading lens the author designed into the text. Failure to name it produces an original-audience section that treats the tabernacle as a later theological overlay rather than the interpretive frame the first readers brought with them.

---

### Who is the original audience?

| Question | Implications |
|----------|--------------|
| Are they covenant Israelites? | They know Torah, the festivals, the geography, the priesthood |
| Are they exilic / post-exilic? | They feel the unresolved tension of God's promises vs current reality |
| Are they early Jewish Christians? | They know the OT deeply and Jesus's life recently |
| Are they Gentile Christians? | They don't know the OT background instinctively; the writer often catches them up |
| Mixed audience? | Tensions over Jewish-Gentile relations (Acts, Galatians, Ephesians) |
| Suffering audience? | The whole tone of address changes — comfort, perseverance, hope |
| Wealthy / poor audience? | Different sermons for the rich (James) vs persecuted poor (Hebrews; Revelation) |
| Pastors / leaders? | Letters to Timothy, Titus operate differently from letters to whole churches |

### What did they expect?

When the original hearers came to this passage, what would they have *expected*? And what did the passage instead *deliver*?

**The technique:** find the places where the passage **subverts**, **fulfils**, or **transforms** an expectation. These are usually where the meaning lives.

| Expectation | Subversion / fulfilment |
|-------------|------------------------|
| Messiah will be a political-military king | Messiah serves and suffers |
| Salvation is for Jews; Gentiles must convert fully | Gentiles included without circumcision |
| The temple is where God meets people | Jesus is the temple |
| Sacrifices continue forever | One final sacrifice in Christ |
| The land is the inheritance | The heavenly country is the inheritance |
| Righteousness comes by law-keeping | Righteousness comes by faith in Christ |
| The kingdom comes in obvious cosmic intervention | The kingdom comes hidden, like seed, mustard, leaven |
| A woman cannot teach Torah / lead prayer | Women teach (Priscilla) and prophesy and serve as deacons |
| A leader must be high-born and rich | A leader must be a servant |
| Death is the end | Resurrection |

### What would have shocked, surprised, comforted, or disturbed them?

For the passage in front of you, ask specifically:

| Type | Description |
|------|-------------|
| **What's shocking?** | Moments the first hearers would have gasped, raised eyebrows, or felt the impropriety |
| **What's surprising?** | Where the passage goes against expectation or convention |
| **What's comforting?** | The reassurances that landed in their context |
| **What's disturbing?** | The warnings, hard sayings, or accusations directed at them |
| **What's funny?** | Yes — the Bible has humour, irony, sarcasm (Elijah and the prophets of Baal; Paul's "may they emasculate themselves") |
| **What's familiar?** | Conventions that were standard — type-scenes, common idioms, expected forms |

### What's missing from our reading?

The flip side: what do **we** bring that **they** didn't?

| What we bring | How it distorts |
|---------------|-----------------|
| Individualism | "You" plural becomes "me singular" — most NT addresses are corporate |
| Post-Enlightenment skepticism | "Did this really happen?" — they would have asked, "What does this mean?" |
| Therapeutic culture | Reading Bible for "what does this do for me?" |
| Modern democratic / egalitarian instincts | Honour-shame and hierarchical relationships seem alien |
| Modern romantic-love marriage | Their marriage was an alliance, not primarily emotional |
| Capitalism / consumerism | Their economy was agricultural, kinship-based, subsistence-level for most |
| Pluralism | Many gods was the default; one-God was the strange position |
| Christianity as private religion | Their religion was public and political |
| Time as linear / progress-oriented | Their time was cyclical-and-eschatological |

---

## Specific reception phenomena worth surfacing

### Honour and shame

Most of the biblical world operates on honour-shame more than guilt-innocence. Key signals:

- Public reputation matters more than internal state
- Shaming and being shamed are major events
- Refusing hospitality is a major insult
- Hands and feet are honourable; foot-washing is degrading
- Sitting at the right hand = honour; outer darkness = shame
- A woman's interaction with men is bounded by honour codes
- A father's authority over family honour is significant
- Crucifixion is the maximum shame (the "shame" of the cross — Heb 12:2)

Watch for honour-shame language: "ashamed", "boast", "glory", "shame", "honour", "blessed", "cursed". And for honour-shame *dynamics*: who challenges whom; who saves face; who is publicly elevated or humiliated.

### Patron-client structures

Most ANE / Greco-Roman relationships outside family are patron-client:

- A patron gives benefits to clients
- Clients owe loyalty, public honour, service
- Refusing benefits is a major insult
- Receiving benefits without proper response is shameful
- God-as-patron, prayer-as-petition, worship-as-honour-giving makes deep sense in this frame
- "Friend" often means "client" or "ally", not just "buddy"

### Family and household

The household (*oikos*) was the basic social unit, much larger than modern nuclear family:

- Extended family, slaves, freedmen, dependents, clients all in the *oikos*
- The head of household had real authority and responsibility
- "Household codes" (Eph 5–6, Col 3, 1 Pet 2–3, Titus 2) address this structure
- Conversion of a household head often brought everyone with him (Acts 16:31–34)
- "Church in the house" was the default first-century church form

### Group identity over individual

- "You" in NT letters is usually plural
- Decisions are made by groups, not just individuals
- Identity is found through belonging
- Sin and righteousness can have corporate as well as individual dimensions
- Conversion was often public and communal

### Oral culture

- Most people heard, didn't read
- Written texts were composed to be read aloud
- Memorability shaped composition (parallelism, repetition, rhythm)
- Length of paragraphs, "verbal triggers" for recall
- This shapes how Paul writes, how Psalms work, how Proverbs functions

---

## Operational guidance for the report

Structure:

```markdown
## Original Audience Reception

### Canonical audience

- **Canonical section:** [Torah / Nevi'im / Writings — and what that means for the reader's horizon]
- **What the canonical reader knows:** [Everything before this book in the canon; specific knowledge most relevant to this passage]
- **Canonical register:** [Which books are canonical neighbours; what reading habits that implies]

### The first hearers

- **Who they were:** [briefly — Jewish, Gentile, mixed, suffering, etc.]
- **Their situation:** [what was pressing on them]
- **What they brought to the passage:** [expectations, conventions, anxieties]

### Where the passage fits their world

[1–3 specific things they would have understood, expected, or felt that we don't naturally pick up]

### Surprises, shocks, comforts, disturbances

- **Shocking:** [what would have startled them]
- **Surprising:** [what subverted expectation]
- **Comforting:** [what reassured them]
- **Disturbing:** [what challenged them]

### What we bring that they didn't

[Modern assumptions or instincts that distort the reading]

### Candidate Fallen Condition Focus

Name the **concern the first readers held that we also share** — the thing that makes this passage's purpose good for us too. This is the downstream source of the Big Question in `/seven-second-sermon` (Chappell's Fallen Condition Focus, via Davies). *Feelings bridge the millennia where circumstances cannot.*

Derive from the reception work above — especially disturbances, comforts, what they brought, their situation — not from contemporary cultural analysis.

| Field | Content |
|-------|---------|
| **What they felt** | [anchored to text/situation — tag [T] or [I]] |
| **Candidate FCF (shared concern)** | [one sentence — the concern we hold in common] |
| **Shared / differs** | [what rhymes; what does not — e.g. this side of the resurrection] |
| **Confidence** | [anchored / inferred] |

**Guardrails:**

- Do not name a candidate FCF you cannot anchor to the reception work above.
- Do not import contemporary "felt needs" — discover in the them-then.
- This is a **candidate** for `/point-purpose` and `/seven-second-sermon` to confirm or refine, not the Big Question itself.
- If the shared concern will not surface from the text alone, say so honestly (`FCF not yet surfaceable from text — corporate listening may be needed downstream`) rather than manufacturing universality.

### Implication for the sermon

[How recovering original-audience reception changes what should be emphasised, recovered, or named]
```

---

## Pitfall

**Romanticising** the ancient world ("they were so much more spiritual"). They weren't.

**Despairing of recovery** ("we can't possibly know what they thought"). Often we can — sometimes precisely. Be honest about uncertainty but don't abdicate the work.

**Over-emphasis on cultural difference** at the expense of universal human experience. They were not aliens; they were us in different clothes. The most universal things in Scripture (love, fear, hope, sin, grace) are common ground.

**Confusing recent academic fashions with first-century reality.** Honour-shame, patron-client, household — these are well-attested. Some other claims (e.g., highly speculative claims about ancient psychology or sexuality) are more contested. Flag confidence accordingly.
