# Extension: The Schnittjer Pass (Torah passages)

Run this extension for any passage in Genesis–Deuteronomy. It applies Gary E.
Schnittjer's narrative-reading method (The Torah Story) as a disciplined pass
that complements the sixteen tools — it does not replace them. Work the text
first; make intertextual links only with demonstrable signals. Record a one-line
finding for each move that fires and an explicit "nil" where a move genuinely
does not apply (the nil-return is what marks a run pass from a skipped one).
Flag confidence where reaching.

## When to run

- Always, for Genesis–Deuteronomy passages.
- N/A (one line) for non-Torah passages — though the underlying moves
  (leading word, chiasm, type-scene, intertextuality) may still surface under
  Tools 3, 5, 10, and 11.

## The pass — work in order

0. **Locate on the book skeleton.** Which book/division; the book's organising
   principle and leading idea; how this passage serves it. (Genesis:
   particularisation, tôledôt, seed/land/blessing. Exodus: progressive proximity
   of God, from-Egypt/through-wilderness/at-the-mountain. Leviticus: two framed
   halves, the danger of holiness. Numbers: two-generation time-space,
   grumbling, the Moab turn. Deuteronomy: four heading-marked sections, the
   "today" janus, the Shema.)
1. **Narrative selectivity & time.** What is included/omitted; where the narrator
   brakes or accelerates (braking = weight); foreground vs background;
   chronological vs thematic order.
2. **Narrative space.** Places/directions/movements and their symbolic force
   (up/down, east, wilderness, Egypt, proximity to the dwelling).
3. **Structure & shape.** Climax · turning point · janus (faces back and forward)
   · framing/inclusio · proportion · particularisation · mirror imaging/chiasm
   (encloses — do NOT assume the centre is the point) · extended echo effect /
   type-scene (repeated ordering that points beyond itself).
4. **Repetition & linkage.** Repetition within the unit · leading word across the
   unit · comparison/contrast/interchange · wordplay/special words · symbolic
   numbers · ellipsis · foreshadowing.
5. **First vs second reading (narrative surprise).** What the first-time reader
   did not yet know; what reads as foreshadowing on the backward re-read.
6. **Intertextuality (polyacoustic reading).** Earlier Scripture echoed (for OT,
   the earlier OT built on). Progressive imaging (a later text narrated to sound
   like an earlier one — arrows point backward). Multiple imaging (building
   echoes toward the Messiah, heard polyacoustically, NOT flattened into a lone
   "X = Jesus"). Guard both under-reading and over-reading; require textual
   signals. Cross-report load-bearing links to Tool 11.
7. **Do not reduce (irreducibility).** Keep the told story as the theological
   statement; let the story rule the reader (worldview, identity, direction)
   rather than reducing it to a proposition-list.

## Report format

Add a "### Schnittjer Pass" section with:

- **Skeleton:** one line — book · division · leading idea served.
- **Findings:** 3–6 lines of claim-plus-evidence, each tagged to the step it came
  from and confidence-flagged where reaching; lead with the strongest.
- **Echoes/signals:** leading word · structural device · intertextual link(s).
- **Nil returns:** steps that genuinely did not apply.

## Interlock with the sixteen tools

The pass mostly deepens Tools 2, 3, 5, 10, and 11 and the Positional Necessity
Check; where a Schnittjer finding is load-bearing, cross-report it into the
relevant tool and (if convergent and high-confidence) Headline Findings. Keep
warrant tags ([T]/[I]/[S]) as elsewhere.

## Guardrails

- Structure is the vehicle, never the object — don't force patterns.
- The centre of a chiasm is not automatically "the point."
- Prefer polyacoustic, building echoes over flat one-to-one typology.
- An explicit nil-return beats a silent skip.
