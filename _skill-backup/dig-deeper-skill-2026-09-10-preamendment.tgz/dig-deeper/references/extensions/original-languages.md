# Extension: Original Languages

Hebrew, Aramaic, and Greek lexical, grammatical, and syntactical work that goes beyond the standard Vocabulary tool. Use this extension whenever the original-language data materially affects how the passage should be preached.

This extension complements the Vocabulary tool (`04-words-and-translations.md`), which handles English-level word study. Here we go beneath the English.

---

## When to use this extension

| Definitely use | Skip / brief mention |
|----------------|---------------------|
| Key theological terms with rich lexical fields (*ḥesed, dikaiosynē, hupotassō, agapē, nephesh, ruach*) | Words with straightforward semantic range |
| Distinctive grammatical features (Greek participles, Hebrew conversive *vav*, infinitive absolute, emphatic word order) | Standard syntax |
| Verb tenses/aspects that carry meaning (aorist vs present, perfect, imperfect, prophetic perfect) | Where tense is unremarkable |
| Wordplay, paronomasia, alliteration in the original | Cases where translation captures the sense fully |
| Cases where the original language disambiguates a translation issue | Cases where translations agree |

---

## Hebrew — what to surface

### Lexical observations

| Feature | Why it matters | Example |
|---------|----------------|---------|
| **Semantic range** of key terms | Hebrew words often span concepts English splits | *yārē'* = both fear and revere; *šālôm* = peace, wholeness, prosperity |
| **Word repetition** at the Hebrew level that English varies | Reveals emphasis hidden in translation | *zera* (seed) recurring through Genesis |
| **Roots and word-families** | Theological connections within a semantic field | *kpr* (covering) → atonement, kapporet (mercy seat), Yom Kippur |
| **Hebrew puns and wordplay (paronomasia)** | Often theologically loaded — the most commonly missed Hebrew literary device | "Adam from *adamah*" (man from ground); "Babel" / *balal* (confuse); *nāḥāš* (serpent) / *nĕḥōšet* (bronze) — same N-Ḥ-Š root, four-fold "bronze" in 1 Sam 17:5–6 sounds like a four-fold "serpent" to the Hebrew ear |
| **Consonant reversal / anagram** | When the same three root consonants appear in reversed or rearranged order in two different words, a narrator may be signalling a thematic mirror-relationship between them | Laban (לָבָן, L-B-N) / Nabal (נָבָל, N-B-L) — Nabal is Laban with letters reversed; both are wealthy livestock owners who refuse hospitality to someone carrying God's purposes, and both are associated with a wiser woman who acts where they cannot. **See the hard rules below before flagging any reversal.** |
| **Semantic taxonomy activation** | A word may belong to a well-known classification system (Levitical clean/unclean taxonomy, wisdom vocabulary, creation vocabulary, covenant vocabulary); when that word appears, its surrounding taxonomy is potentially activated | *qasqassîm* (scales, 1 Sam 17:5) is Levitical taxonomy vocabulary (Lev 11:9–12); the clean/unclean taxonomy organised by scales is structured around the serpent as paradigmatic unclean land creature; hearing *qasqassîm* may activate this framework, making the scale vocabulary serpent-adjacent even though scales themselves mark clean creatures in Lev 11. **See the hard rules below before claiming an activation.** |

### Hard rules: sound- and taxonomy-based claims

These two devices are where over-reading most often enters the report. Apply the relevant test before flagging either; do not bury the test in a footnote.

1. **Consonant reversal:** the reversal alone is *never* sufficient evidence. The Hebrew lexicon is small enough that accidental three-consonant reversals are common. Flag a reversal only when it is corroborated by a strong narrative or thematic parallel between the two bearers (shared role, shared scene-type, shared failure — as with Laban/Nabal). No corroboration → treat as coincidence and omit.

2. **Taxonomy activation:** a word activates its classification system only when all three hold: (a) the taxonomy is canonically established *before* this text's horizon; (b) the passage shows at least one other marker from the same taxonomy, or a thematic concern that taxonomy serves; and (c) positing the activation adds explanatory power to the passage's argument — it explains something otherwise puzzling. A lone lexical overlap with a taxonomy fails (b) and (c): note the word, omit the system.

3. **Confidence ceiling:** a claim under either device is *moderate confidence* at best without commentary or canonical-precedent support (e.g. Num 21:9 establishing *nāḥāš/nĕḥōšet* as a canonical word pair raises paronomasia on that root to moderate–high). Tag accordingly and list under Recommended verification.

### Grammatical features

| Feature | Description | Significance |
|---------|-------------|--------------|
| **Vav-consecutive (*wayyiqtol*)** | The "and-then" of Hebrew narrative; sequential action | Marks main narrative flow vs. background |
| **Disjunctive vav (*we-*X)** | Subject-first construction breaking the sequence | Marks foregrounding, contrast, or new scene |
| **Infinitive absolute** | The doubled-up emphatic ("dying you shall die"; "Truly you shall surely die") | Strong emphasis often flattened in translation |
| **Hebrew word order** | Verb usually first; deviations are emphatic | "*God* created the heavens" foregrounds the agent |
| **Cohortatives** | First-person volition ("let us...") | Calls to action; group resolve |
| **Jussives** | Third-person volition ("let X happen") | Wishes, commands, prayer |
| **Hithpael stem** | Reflexive — doing something to/for oneself | "Walked himself" (with God); self-humbling |
| **Hiphil stem** | Causative | Note when an English passive masks a causative |

### Hebrew poetic devices

- **Parallelism** (covered fully in Tool 5)
- **Acrostic** (Lamentations, Pss 9–10, 25, 34, 37, 111, 112, 119, 145; Prov 31:10–31) — structural completeness signal
- **Inclusio** at word level
- **Merismus** ("from rising sun to setting"; "heaven and earth" = everything in between)

### Confidence flagging

- *High confidence:* major lexical claims, common grammar, well-attested poetic devices.
- *Moderate confidence:* less common terms; specific shades of an attested word.
- *Uncertain — consider a lexicon:* anything Claude is reaching for. Recommend BDB, HALOT, NIDOTTE, TDOT.

---

## Greek — what to surface

### Lexical observations

| Feature | Why it matters | Example |
|---------|----------------|---------|
| **Synonyms with shades** | Greek has fine vocabulary distinctions | *agapē* / *philia* / *erōs*; *zōē* / *bios*; *oikos* / *oikia*; *logos* / *rhēma* |
| **Cognate accusative** | Verb + noun from same root for emphasis | "Rejoicing with great joy" |
| **Compound verbs** | Prefixes intensify or specify | *apolytrōsis* (full redemption) vs *lutroō*; *epignōsis* (full knowledge) vs *gnōsis* |
| **Article use** | Greek's the/no-the distinction often signals identity vs category | "in the beginning was the Word" — *ho Logos*, identified one |

### Verb aspect (often more important than tense)

| Aspect | Form | Function |
|--------|------|----------|
| **Aorist** | "Snapshot" — undefined action | Whole-action view; often past simple |
| **Present** | Linear — ongoing action | Continuous, repeated, habitual |
| **Imperfect** | Past linear | "Was doing", ongoing past |
| **Perfect** | Completed with present-time results | The action is done; the state continues |
| **Pluperfect** | Past-perfect | A state existed at a past time as result of earlier action |
| **Future** | Future expectation | |

**Aspect matters in:** imperatives (present imperative for ongoing/habitual action; aorist imperative for specific/one-time), participles (timing relative to main verb), and especially perfect-tense statements that translation often flattens ("It is finished" — *tetelestai* — perfect: done with continuing effect).

### Grammatical features to watch

| Feature | What to flag |
|---------|-------------|
| **Participles** | Adverbial, attributive, supplementary, periphrastic — each function changes meaning |
| **Subjunctive mood** | Possibility, exhortation, deliberative question |
| **Imperative mood** | Direct command; *me* (μή) + present imperative = "stop doing" |
| **Infinitive** | Often expresses purpose, result, content |
| **Genitive absolute** | Background information not grammatically tied to main clause |
| **Word order** | Greek word order is freer than English; deviation from default is emphatic |
| **Conjunctions** | *kai, de, gar, oun, alla, hina, hōste* — fine logical distinctions often lost in translation |

### Conjunction map (often where the argument lives)

| Greek | Function | English |
|-------|----------|---------|
| *kai* | Coordinating, often continuous | and, also, even |
| *de* | Mild contrast, transition, continuation | and, but, now |
| *alla* | Strong contrast | but, rather |
| *gar* | Explanatory grounding | for, because |
| *oun* | Inferential | therefore, so |
| *hōste* | Result | so that, with the result that |
| *hina* | Purpose (sometimes result) | in order that, so that |
| *hoti* | Causal / declarative | because, that |
| *ei* | Conditional (1st class — assumed true; 3rd — uncertain) | if |

### Confidence flagging

- *High confidence:* well-established lexical and grammatical claims.
- *Moderate confidence:* aspectual nuance, less common syntactic constructions.
- *Uncertain — consider a lexicon/grammar:* recommend BDAG (lexicon), Wallace's *Greek Grammar Beyond the Basics*, or NET Bible translator notes.

---

## Aramaic

Don't forget the Aramaic portions: Dan 2:4b–7:28, Ezra 4:8–6:18 and 7:12–26, Jer 10:11. Aramaic shares much with Hebrew but has its own peculiarities. Generally flag this rather than attempt detailed Aramaic work without verification.

---

## Operational guidance for the report

Include this section in the **Original Languages** part of the report. Structure:

```markdown
## Original Language Observations

### Key terms

| Term | Form | Range | Usage here | Confidence |
|------|------|-------|-----------|------------|
| | (Hebrew/Greek) | (lexical range) | (what it means in this passage) | (high/moderate/uncertain) |

### Grammatical/syntactical features

- [Feature]: [observation] *(confidence flag)*
- ...

### Wordplay, repetition, or sound-features in the original

- [If present, what they are and why they matter]

### Recommended verification

- [Anything Claude flagged as uncertain that would benefit from lexicon/commentary consultation]
```

**Be selective.** Don't catalogue every Hebrew/Greek word — 3–8 observations is usually right. The test: *would knowing this materially help the preacher*?

**Pitfall:** Showing off original-language knowledge that doesn't actually affect interpretation. Treating tense as if it always carries the weight it does in English. Word-study fallacies (root fallacy, illegitimate totality transfer, etymological fallacy) — flag if in doubt.
