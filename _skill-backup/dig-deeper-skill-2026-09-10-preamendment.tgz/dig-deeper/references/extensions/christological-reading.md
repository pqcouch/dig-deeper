# Extension: Christological Reading

For OT passages especially, this extension generates the raw material for seeing Christ in the text — what Clowney, Goldsworthy, Duguid, and Beale would surface.

This is **raw material**, not a finished Christological argument. The job is to put the data in front of the preacher so the Teaching Point and sermon shape can be Christ-centred without being moralistic or arbitrary.

Note: For NT passages, Christological reading is usually obvious (Christ is named); this extension is most useful for OT work, but can apply where NT passages depend on OT Christological patterns.

---

## When to use this extension

- **All OT passages.** Yes — even ones that "seem" not to be about Christ. Either the passage points forward to Christ, prepares for Christ, contrasts with Christ, or has Christ as its present meaning (Christophany).
- **NT passages that use OT typology** (Hebrews, much of Matthew, Romans).
- **NT passages that depend on OT institutions** (priesthood, sacrifice, kingship, exodus, temple).

Skip if the book-overview has already worked the Christological trajectory comprehensively at the passage level (use the book-overview's work; complement rather than duplicate).

---

## Five ways an OT passage relates to Christ (Clowney / Goldsworthy / Duguid)

### 1. Direct prophecy

The passage explicitly predicts Christ's coming, person, or work.

| Examples |
|----------|
| Isa 7:14 (virgin birth) |
| Isa 9:6–7 (the child given) |
| Isa 53 (suffering servant) |
| Mic 5:2 (born in Bethlehem) |
| Zech 9:9 (king on a donkey) |
| Zech 12:10 (the one they pierced) |
| Ps 2 (the anointed Son) |
| Ps 22 (the cry of dereliction) |
| Ps 110 (the king-priest) |
| Dan 7:13–14 (Son of Man) |

For these, surface what the prophecy specifies and how Christ fulfils it.

### 2. Typology

The passage features a person, event, or institution that prefigures Christ — a Christ-shaped pattern in the OT.

**Persons typologically pointing to Christ:**

| OT figure | Type-relationship with Christ |
|-----------|-------------------------------|
| Adam | Federal head of humanity; Christ as "last Adam" (Rom 5; 1 Cor 15:45) |
| Abel | Righteous one slain; Christ's blood "speaks better than Abel's" (Heb 12:24) |
| Melchizedek | Priest-king without recorded genealogy; Christ as priest in his order (Heb 7) |
| Isaac | Beloved son; offered up; received back "as from death" (Heb 11:19) |
| Joseph | Rejected by brothers, raised to power, becomes saviour of those who rejected him |
| Moses | Mediator of covenant; deliverer; prophet greater to come (Deut 18:15) |
| Joshua | Leads God's people into rest; namesake (Yeshua/Jesus) |
| David | Anointed king after God's heart; rejected before reigning |
| Solomon | Wisdom; temple-builder; international kingdom — partial Christ-type |
| Elijah | Prophetic forerunner — John Baptist as "Elijah" (Mark 9:13); pattern |
| Jonah | Three days in the depths; sign of Christ (Matt 12:39–41) |
| The suffering servant figures | Job, Jeremiah, Daniel, Hosea — patterns of righteous suffering |

**Events typologically pointing to Christ:**

| OT event | Type-relationship |
|----------|-------------------|
| Creation | New creation in Christ (2 Cor 5:17; Col 1:15–20) |
| Flood | Judgment + remnant rescue; baptism analogy (1 Pet 3:20–21) |
| Exodus | Christ's "exodus" at Jerusalem (Luke 9:31); freedom from slavery to sin |
| Passover | Christ as our Passover lamb (1 Cor 5:7); blood causing judgment to pass over |
| Red Sea crossing | Baptism analogy (1 Cor 10:2) |
| Wilderness manna | Christ as bread of life (John 6:32–35) |
| Rock struck for water | "The rock was Christ" (1 Cor 10:4) |
| Bronze serpent | "Just as Moses lifted up..." (John 3:14) |
| Conquest of Canaan | Christ's victory; rest entered |
| David's kingdom | The greater David's kingdom |
| Exile | We were exiled from God; Christ brings us home |
| Return from exile | Christ as the true returnee, bringing the people back |

**Institutions typologically pointing to Christ:**

| Institution | Christ-fulfilment |
|-------------|-------------------|
| Sacrifice (all categories) | "Once for all" (Heb 9:26) |
| Priesthood | Christ the great high priest (Heb 4–10) |
| Tabernacle / Temple | Christ as God's dwelling (John 1:14; John 2:21) |
| Day of Atonement | Christ's death as the great atoning act |
| Kingship | Christ as Messiah-king |
| Prophet (office) | Christ as the prophet (Acts 3:22; Heb 1:1–2) |
| Sabbath | Rest in Christ (Heb 4:9–10) |
| Festivals | Various Christ-fulfilments (Passover, Pentecost, Tabernacles) |
| Circumcision | Heart-circumcision in Christ (Col 2:11) |
| Land | The heavenly country (Heb 11:16) |
| Marriage covenant | Christ and the church (Eph 5) |

### 3. Christophany (or "the angel of the LORD")

The passage features an OT appearance of God that is plausibly a pre-incarnate appearance of the Son.

| Likely Christophanies |
|----------------------|
| The "angel of the LORD" appearing as a divine figure (Gen 16, 22; Exod 3; Judg 6, 13) |
| The "commander of the LORD's army" (Josh 5:13–15) |
| The "fourth man in the fire" (Dan 3:25) |
| The man wrestling Jacob (Gen 32) |

Flag the strong cases; don't overclaim. *Confidence: moderate to high* for the strongest cases; *uncertain* for less direct theophanies.

### 4. Trajectory / development

The passage advances a theme that culminates in Christ.

Many OT passages don't fit categories 1–3 but participate in the larger story that finds its goal in Christ:

| Trajectory examples |
|---------------------|
| Genesis 3:15 → the long line of "seed" promises → Christ |
| Davidic covenant → the failure of Davidic kings → Christ as the true David |
| Israel as God's "son" → Israel's failure → Christ as the true Israel |
| The temple's glory departing → no glory in the second temple → glory returns in Christ |
| The unfulfilled hopes of the prophets → fulfilled in Christ |
| The Servant Songs → Christ as the Servant |

For these, the question is: *what is the OT longing for, that Christ fulfils?*

### 5. Contrast / counter-pattern

The passage shows a need, a failure, or a longing that Christ answers.

| Contrast examples |
|-------------------|
| Adam fails the test in the garden → Christ passes the test in the wilderness |
| Moses cannot enter the land → Christ leads us into the true land |
| David falls into adultery and murder → Christ remains faithful |
| The high priest must offer sacrifice for his own sin → Christ has no sin |
| The Levitical sacrifices must be repeated → Christ's sacrifice is final |
| Israel grumbles in the wilderness → Christ trusts the Father in his wilderness testing |
| Solomon's wisdom turns to apostasy → Christ is the wisdom of God |
| The kings of Israel fail → the King of kings reigns |

For these, the question is: *what does this passage's failure or longing reveal that Christ answers*?

---

## Distinguishing real typology from imposed connection

Before claiming any typological connection, run these four tests. State in the report which tests the claim passes — the tally sets the confidence flag.

1. **Theological-category test.** The connection runs through an established theological category (priesthood, kingship, sacrifice, exodus, temple, covenant mediation, sonship) rather than an incidental detail (a colour, a number, an object). Rahab's scarlet cord fails; Melchizedek's priesthood passes.
2. **NT-precedent test.** Strongest: the NT makes this exact connection explicitly (bronze serpent → John 3:14). Strong: the NT makes the same *kind* of connection with a parallel figure or event (if Joseph-as-rejected-deliverer, cf. the rejected-stone pattern the NT applies repeatedly). Weak: no NT precedent for the kind of connection at all — flag *uncertain* and say so.
3. **Escalation test.** Genuine types escalate: the antitype is greater, the fulfilment exceeds the pattern (Heb 7–10's "how much more" logic). If Christ merely *resembles* the OT figure without surpassing him, you may have an illustration, not a type — still usable, but label it honestly.
4. **Authorial-pattern test.** Does the OT text itself signal the pattern — repeated vocabulary, structural prominence, an expectation it raises and leaves unresolved? Or does the connection exist only when read backwards from the NT? Backwards-only connections can be legitimate, but they are **trajectory** readings, not typology — categorise them as such.

**Scoring:** passes all four → *high confidence* typology. Passes 1 plus two others → *moderate*. Passes two or fewer → reclassify (trajectory or contrast) or drop. Passes none → allegorising; omit.

---

## The Christ-in-OT trap (moralism)

Goldsworthy's warning: it is possible to preach the OT and never preach Christ. Three signs of moralistic OT preaching:

1. **The application is essentially "be like X"** — be like David's courage, be like Daniel's faithfulness, be like Esther's bravery. Without Christ, this becomes works-righteousness.
2. **The hero of the passage is the human figure, not God or Christ.** "David and Goliath" becomes about David's courage rather than about God giving victory through his anointed.
3. **The "good news" is information about God's character without grounding in Christ's saving work.** "God is faithful" preached without "Christ has been faithful for us" leaves hearers with duty, not gospel.

The corrective: ask, for every OT passage:
- *Where is Christ in this passage's trajectory, type, or contrast?*
- *How does the gospel ground this passage's call?*
- *Is the application "be like X" — or is it "trust the Christ whom X points to"?*

---

## Operational guidance for the report

Structure:

```markdown
## Christological Reading

### Type of Christological connection

[One or more of: direct prophecy / typology / Christophany / trajectory / contrast. For any typology claim, note which of the four tests (category / NT precedent / escalation / authorial pattern) it passes.]

### How the passage points to Christ

[The specific connections. Be concrete: who/what is the type, how does Christ fulfil it, what does the trajectory specify?]

### Trajectory

- **What the passage anticipates or longs for:** [explicit or implicit]
- **What Christ fulfils:** [briefly — direct fulfilment, transformation, or unexpected reframing]
- **What still remains (already / not yet):** [if applicable]

### Moralism check

- **The "be like X" temptation in this passage:** [what it would be]
- **The gospel grounding:** [where in salvation history this passage's call gets its foundation]
- **Christ as hero, not just example:** [where Christ becomes the subject, not just an analogy]

### Confidence

*high / moderate / uncertain* on the strongest typological claims.
```

---

## Recommended sources for further depth

- Goldsworthy, *Preaching the Whole Bible as Christian Scripture*
- Clowney, *Preaching Christ in All of Scripture*
- Duguid, *Is Jesus in the Old Testament?*
- Beale & Carson, *Commentary on the New Testament Use of the Old Testament*
- Greidanus, *Preaching Christ from the Old Testament*

---

## Pitfall

**Allegorising** instead of typology — finding Christ in every detail in arbitrary ways (the scarlet cord, the door of the ark, etc., pressed too hard). The test for typology: is the Christ-connection rooted in the *theological category* (priesthood, kingship, sacrifice, exodus) rather than incidental detail?

**Christomonism** — making every OT passage equally and immediately about Christ regardless of its historical particularity. The OT really is *also* about God's dealings with Israel; that's not erased.

**The opposite pitfall** — refusing to see Christ at all in the OT. The NT itself authorises and demands Christological reading (Luke 24:27; John 5:39; 1 Cor 10).
