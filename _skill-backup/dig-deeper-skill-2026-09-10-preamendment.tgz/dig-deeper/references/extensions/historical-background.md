# Extension: Historical and Cultural Background

The original audience knew things we don't: geography, customs, political situations, social hierarchies, religious practices, building layouts, agricultural rhythms, family structures, legal codes. What they would have understood without explanation is often what we miss most. This extension surfaces that.

---

## When to use this extension

Almost always. Even passages that seem "self-explanatory" often have background that materially affects meaning. The test is: *did the original audience know something I don't, that changes how I read this?*

Skip only if:
- The passage is doctrinal abstraction without historical setting (some psalms about God's character; some wisdom passages)
- Every detail of background is already in the book-overview's presenting situation

---

## What to look for

### Geographic / topographic

| Question | Why it matters |
|----------|----------------|
| Where does this take place? | A journey, a city, a region — each has connotations |
| What was the place known for? | Galilee = backwater; Jerusalem = political/religious centre; Samaria = mixed-race; Nazareth = nothing good |
| What's the topography? | Going *up* to Jerusalem (always, regardless of direction). Down to Jericho. Climbing a mountain to meet God |
| Distance / journey time? | Affects pacing: Jesus walked, took days; the urgency of Acts journeys |
| Proximity to other places? | Jesus retreating across the lake; Paul's circuit through Asia Minor |

### Political

| Question | Why it matters |
|----------|----------------|
| Who is in power locally? | Roman governor, Herod, Sanhedrin — each carries weight |
| What's the political situation? | Occupation, exile, war, peace, revolt, succession crisis |
| Power dynamics in the room? | Who can arrest whom; who answers to whom |
| Recent events shaping mood? | Jewish revolts, Roman expulsions, famines, the destruction of Jerusalem |

### Social / cultural

| Question | Why it matters |
|----------|----------------|
| Honour/shame dynamics? | First century is honour-shame culture; modesty, public reputation, family honour |
| Patron/client relationships? | "Friend of Caesar" is a political relationship; God-as-patron, prayer-as-petition |
| Clean/unclean categories? | Touching the dead, lepers, menstruating women — and the shock when Jesus violates these |
| Gender roles? | Women at the well, women as first witnesses to resurrection, Paul's mixed practices |
| Slavery dynamics? | Roman slavery is everywhere — affects parables, household codes, Philemon |
| Age/seniority? | Older brother privileges (Esau, prodigal); honouring elders |
| Hospitality codes? | The shame of refusing a guest; the danger of refusing to host (Luke 9:53) |
| Meals as social events? | Who eats with whom is political/religious (Jesus and tax collectors) |
| Marriage and family structures? | Bridal customs, betrothal vs marriage, levirate marriage, polygamy |

### Religious

| Question | Why it matters |
|----------|----------------|
| What's the temple/synagogue context? | Festivals, sacrifices, courts, who can enter where |
| Jewish sects and their views? | Pharisees, Sadducees, Essenes, Zealots, Herodians — each has positions |
| Sabbath laws and traditions? | Most Gospel conflicts hinge on these |
| Festival timing? | Passover, Pentecost, Tabernacles — context for almost every Gospel scene |
| Purity laws operating? | Affects every dietary mention, every healing, every encounter |
| Gentile / Jewish boundaries? | Court of the Gentiles, dietary boundaries, intermarriage — Acts narrative pivots on these |

### Economic

| Question | Why it matters |
|----------|----------------|
| Currency mentions? | A denarius = day's wage; a talent = ~15 years' wages |
| Trade and commerce? | Tax collectors as collaborators; fishing economy; agricultural cycles |
| Wealth disparity? | Land-owning elite vs day labourers; debt-slavery cycles |
| Famine, taxation, debt? | Backdrops to many parables and prophetic warnings |

### Linguistic / literary culture

| Question | Why it matters |
|----------|----------------|
| Languages in play? | Hebrew (scholarly/sacred), Aramaic (everyday OT-era and 1st cent), Greek (commercial/imperial), Latin (Roman administrative) |
| Literacy levels? | Most people heard, didn't read — affects how books were composed (memorability, oral patterns) |
| Letter conventions? | Pauline letters follow Greco-Roman conventions with theological adaptations |
| Rhetorical conventions? | Diatribe, chreia, encomium — NT writers use Greek rhetorical forms |
| Storytelling conventions? | Type-scenes (meeting at the well, mountain-top revelation, garden temptation) |

---

## Background by canonical period

### Patriarchal era (Genesis 12–50)
Bedouin / semi-nomadic existence. Family-clan structure. Polygamy and concubinage common. Treaties and covenants formalised by ritual. Egyptian context for Joseph narrative (court bureaucracy, dream interpretation as profession).

### Exodus / wilderness
Egyptian slavery, Pharaoh as god-king, plagues confronting Egyptian deities. Wilderness as both judgment and formation. Tabernacle borrowing/transforming ANE temple conventions.

### Conquest / Judges
Tribal confederacy. Canaanite religion (Baal, Asherah, Molech) — sex and child sacrifice as central. No king — local, charismatic leadership.

### United Monarchy (Saul, David, Solomon)
Davidic covenant. Temple construction. Court politics. Royal ideology drawing on (and distinguishing from) ANE kingship.

### Divided Kingdom
Northern (Israel, capital Samaria) vs Southern (Judah, capital Jerusalem). Prophetic ministry to both. Syncretism with Canaanite religion in the north especially.

### Assyrian / Babylonian invasions
720 BC fall of Samaria; 586 BC fall of Jerusalem. Exile reshapes Jewish identity around Torah and synagogue (in absence of temple).

### Persian period (538 BC onwards)
Cyrus's edict allows return. Rebuilding of temple (515 BC) and walls (445 BC). Persians generally tolerant; allow theocratic governance.

### Hellenistic period (332 BC onwards)
Alexander conquers. Greek culture pressure. Ptolemies then Seleucids rule. Maccabean revolt (167–164 BC) over Antiochus IV's desecration. Hasmonean dynasty.

### Roman period (63 BC onwards)
Roman power, client kings (Herod the Great and family), procurators (Pilate), occupation, taxation, periodic revolt. AD 70: destruction of the temple by Titus.

### Second-Temple Judaism (the world of Jesus and the apostles)
- **Pharisees:** popular party emphasising Torah application via oral tradition; resurrection; angels; precise tithing and Sabbath
- **Sadducees:** priestly aristocracy; Torah only (no resurrection, no angels); Temple-centric; collaborated with Rome
- **Essenes:** sectarian, often ascetic, expecting imminent eschaton (Qumran community probably one example)
- **Zealots:** militant nationalists seeking armed liberation
- **Herodians:** politically aligned with Herodian family
- **Samaritans:** mixed-race remnant of Northern Kingdom + Assyrian transplants; their own temple at Gerizim (destroyed 128 BC); their own Pentateuch
- **God-fearers:** Gentiles attracted to Jewish monotheism without full conversion; key for Acts
- **Hellenistic Jews / Diaspora:** Greek-speaking, often using LXX
- **Synagogue:** the everyday focus of Jewish religious life; preaching, prayer, Torah-reading

### Apostolic / NT era
Spread of Christianity through Roman roads, sea trade, Jewish diaspora, household structures. Persecutions: Jewish (Acts), then Roman (Nero AD 64; sporadic local persecution; Domitian late 1st cent).

---

## Common background items worth flagging

| Item | Background |
|------|------------|
| **Synagogue ruler** | Lay leader; responsible for service; Jairus, Sosthenes |
| **Tax collector** | Roman collaborators; bought tax franchises; profit by over-collecting; despised |
| **Centurion** | Roman officer over 100 men; often viewed favourably in Gospels |
| **Pool of Bethesda** | Northern Jerusalem, near sheep gate; archaeologically located 1880s; five porticoes confirmed |
| **Pool of Siloam** | Hezekiah's tunnel water source; Feast of Tabernacles water-pouring rite (John 7) |
| **Mount of Olives** | East of Jerusalem; Zechariah 14 prophecy about the Mount splitting; Jesus's ascension |
| **Bethsaida, Capernaum, Chorazin** | Sea-of-Galilee towns; Jesus's primary ministry base |
| **Decapolis** | Ten Greek-speaking cities east of Galilee; Gentile context |
| **Tyre and Sidon** | Phoenician cities; OT enemies; Jesus's surprising ministry there |
| **Praetorium** | Roman governor's residence/judgment hall |
| **Areopagus** | Athenian council/hill; intellectual and judicial centre |
| **Asia (province)** | Western Anatolia; capital Ephesus; the seven churches of Revelation are here |
| **Diaspora / "scattered"** | Jews living outside Palestine; key for Acts mission strategy |
| **Mikveh** | Ritual bath for purification — relevant for baptism background |
| **Phylacteries / tefillin** | Small leather boxes with Torah verses, worn on forehead/arm (Matt 23:5) |
| **Tassels / tzitzit** | Fringe on garment commanded in Num 15; "edge of his garment" healings |
| **The Talmud / Mishnah** | Later collections, not 1st cent — but preserve earlier traditions; cite with caution |

---

## Operational guidance for the report

Include this section as **Historical and Cultural Background** in the report. Structure:

```markdown
## Historical and Cultural Background

### Setting

- **Time period:** [when this occurs / when this was written]
- **Location:** [where, with relevant features]
- **Political context:** [who is in power, recent events shaping mood]

### What the original audience knew

[3–8 specific things the first hearers would have understood without explanation that shape how the passage should be read. Each as a brief paragraph or bullet.]

### What this changes about how we read

[1–2 specific examples of how the background reframes what would otherwise be missed or misread.]
```

**Be specific and selective.** Don't dump everything you know about first-century Palestine. The test: *would knowing this materially help the preacher engage the original meaning*?

**Confidence flagging:** Background information is generally well-attested but flag *uncertain — consider verifying* on:
- Specific archaeological claims
- Dating of events or movements
- Anything about Talmudic or Rabbinic literature (date carefully — much is later than the NT)

**Recommended references for verification:**
- *Dictionary of Jesus and the Gospels* (IVP)
- *Dictionary of Paul and His Letters* (IVP)
- *Dictionary of the Old Testament* (multiple volumes, IVP)
- Keener, *IVP Bible Background Commentary*
- Bock, *Jesus According to Scripture* (for Gospel material)

---

## Pitfall

Over-claiming background knowledge that's actually post-NT (especially Rabbinic material that may not represent 1st-century thinking). Romanticising ANE customs. Importing modern Middle Eastern customs as if they were 1st-century customs. Confusing what's *interesting* with what's *materially useful for this sermon*.
