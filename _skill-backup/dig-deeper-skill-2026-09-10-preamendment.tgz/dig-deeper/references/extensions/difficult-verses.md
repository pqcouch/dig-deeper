# Extension: Difficult and Controversial Verses

The preacher's job is partly to anticipate where hearers will get stuck. This extension flags verses in (or adjacent to) the passage that:

1. Hearers may find ethically troubling
2. Have major interpretive disagreement among orthodox Christians
3. Are commonly weaponised or misused
4. Raise apologetic / hard questions
5. Carry doctrinal weight in ways that demand careful handling

The goal is *not* to resolve these from the pulpit, but to ensure the preacher has thought about them before the sermon, not during it.

---

## Categories of difficulty

### Ethically troubling passages

Passages that ordinary modern hearers (and Christians) find morally difficult:

| Type | Examples |
|------|----------|
| **Divine violence / herem warfare** | Joshua 6 (Jericho), 1 Sam 15 (Amalekites), Deut 7 |
| **Imprecatory psalms** | Ps 137:9 ("dash the little ones..."), Ps 109, Ps 69 |
| **Slavery** | OT slave laws (Exod 21), NT household codes (Eph 6:5–9; Col 3:22; 1 Pet 2:18; Philemon) |
| **Sexual ethics now-contested** | 1 Cor 6:9–11; Rom 1:26–27; Lev 18; Lev 20 |
| **Women's roles** | 1 Tim 2:11–15; 1 Cor 14:34–35; 1 Cor 11:2–16; Eph 5:22–33 |
| **Hell / eternal punishment** | Matt 25:46; Rev 14:9–11; 2 Thess 1:9 |
| **Divine commands of seemingly cruel things** | Gen 22 (binding of Isaac); Hos 1 (marry a prostitute) |
| **OT laws now strange to us** | Various Levitical laws — purity, food, mixed fabrics |
| **Suffering of the innocent** | Job; the slaughter of the innocents (Matt 2); Heb 11:35–38 |
| **Patriarchal narratives' moral ambiguity** | Lot's daughters; Tamar; Jacob's deceptions; Judah's failure |

For each, the preacher needs:
- The exegetical answer (what the text actually says, in its own setting)
- The biblical-theological frame (how it sits in the canon, especially relative to Christ)
- Some pastoral wisdom on tone, not just content

### Doctrinally contested passages

Passages where orthodox Christians genuinely disagree:

| Issue | Common contested texts |
|-------|------------------------|
| **Election / free will** | Rom 9; Eph 1; John 6; Acts 13:48; 2 Pet 3:9 |
| **Eternal security / falling away** | Heb 6:4–6; Heb 10:26–31; John 10:28–29; 1 John 2:19 |
| **Charismatic gifts** | 1 Cor 12–14; Acts 2, 8, 10, 19; 1 Cor 13:8–10 |
| **Baptism (mode, subjects)** | Acts 16:15, 33; Col 2:11–12; 1 Cor 7:14; Matt 28:19 |
| **Lord's Supper (real presence, frequency)** | 1 Cor 11:23–34; John 6:53–58; Luke 22:19 |
| **Eschatology (millennium, rapture, hell)** | Rev 20; 1 Thess 4:13–18; Matt 24; 2 Pet 3 |
| **Women in leadership** | 1 Tim 2; 1 Tim 3; Rom 16:1–7 (Phoebe, Junia); Gal 3:28 |
| **Marriage and divorce** | Matt 19; Mark 10; 1 Cor 7; Mal 2:16 |
| **Israel and the church** | Rom 11; Gal 3; Eph 2:11–22; the land promises |
| **Sanctification (perfectionism, progressive)** | 1 John 3:9; Rom 7; Phil 3:12–14 |
| **Cessationism / continuationism** | 1 Cor 13; Eph 2:20; Heb 1:1–2 |
| **Limited / unlimited atonement** | 1 Tim 2:4–6; 2 Pet 2:1; 1 John 2:2; John 10:11; Heb 2:9 |

### Commonly weaponised or misused

Verses regularly pulled from context for purposes the original would not endorse:

| Verse | Common misuse |
|-------|---------------|
| Jer 29:11 | "Plans to prosper you" applied to individual career success — context: exile, not personal flourishing |
| Phil 4:13 | "I can do all things" — context: contentment in plenty or want, not athletic/career achievement |
| Matt 7:1 | "Judge not" used to silence moral assessment — context: hypocritical judgment specifically |
| Matt 18:20 | "Where two or three are gathered" — about church discipline, not small attendance |
| Rom 8:28 | "All things work together for good" — to all? No, to those who love God; and "good" = conformity to Christ |
| 1 Cor 2:9 | "Eye has not seen..." applied to heaven — Paul applies it to what God *has* now revealed by the Spirit |
| Heb 11:1 | "Faith is the substance of things hoped for" — not "name it and claim it" |
| Mark 11:23–24 | "Whatever you ask in prayer..." stripped from context of fig tree/temple/judgment |
| 2 Chron 7:14 | "If my people..." applied to nations not in covenant relationship as Israel was |
| Mal 3:10 | "Bring all the tithes..." used in prosperity gospel; original context: covenant Israel |
| Ps 91 | "No evil will befall you" — used to deny ordinary suffering; in context conditional on dwelling in shelter |
| John 10:10 | "Abundant life" reduced to material prosperity |
| Gen 1:28 | "Be fruitful and multiply" used in various agendas — environmental, fertility |
| Acts 2:38 | "Repent and be baptised" used in baptismal regeneration debates |
| Gal 3:28 | "Neither Jew nor Greek..." flattened to remove all role distinctions |
| Rev 3:20 | "Behold I stand at the door" — to unbelievers, when context is a lukewarm church |

### Apologetic difficulties

Passages where reasonable seekers ask sharp questions:

| Type | Examples |
|------|----------|
| **Apparent contradictions** | Synoptic vs Johannine timing of Last Supper; Acts 9 vs 22 vs 26 differences; the two accounts of Judas's death |
| **Apparent moral failures by Bible characters with no narrator condemnation** | Abram lying about Sarai; Lot offering daughters; the patriarchs polygamously |
| **Historical / scientific tensions** | Gen 1; the flood; Joshua's long day; Jonah; the census of Quirinius |
| **Divine knowledge / foreknowledge tensions** | God "repenting" (Gen 6:6; 1 Sam 15:11); God being "grieved" |
| **Salvation of OT saints** | Did they know Christ? How were they saved? |
| **Fate of the unevangelised** | Rom 1; Rom 2:14–15; Acts 17:30 |
| **Hardening of hearts** | Pharaoh; Rom 9 |

### Pastorally sensitive

Topics where hearers may be acutely personally affected:

| Topic | Likely struggles in the room |
|-------|------------------------------|
| **Marriage / divorce** | Divorced hearers; struggling marriages |
| **Sexual ethics** | Single people, LGBT individuals, those with past sexual sin, victims of sexual abuse |
| **Mental health** | Depression, anxiety, suicidal ideation |
| **Suffering / theodicy** | Recently bereaved, chronically ill, traumatised |
| **Money / generosity** | Financial pressure, wealth guilt, prosperity-gospel scars |
| **Family** | Estranged from family, infertile, lost children, abusive parents |
| **Doubt / deconstruction** | Wavering faith, leaving the church |
| **Race / nation** | Recent racial tensions, immigration debate, war |
| **Past in the church** | Spiritual abuse, hypocrisy, legalism, controlling leadership |

---

## What to do for the report

Scan the passage and 1–2 verses around it. For each issue surfaced, structure:

```markdown
## Difficult / Contested Verses

### [Verse reference] — [issue]

- **Category:** [ethical / doctrinal / weaponised / apologetic / pastoral]
- **The difficulty:** [briefly state what's hard]
- **Common misreadings / mishandlings:** [what to watch for]
- **Rhetorical function in context:** [before listing interpretive options, ask — what work is this verse doing within the passage's own argument or flow? Is it an assurance, a warning, a climax, a bridge, a ground, a qualification? The passage's internal logic often constrains the plausible interpretations: a verse functioning as assurance after a demanding call narrows the referent differently than one functioning as warning. State the verse's role in the passage before adjudicating between options.]
- **The main interpretive options:** [for genuinely contested issues — name them without forcing a resolution]
- **What an honest exegesis surfaces:** [where the textual evidence points, with confidence flagging]
- **Suggested handling for the preacher:** [acknowledge / address briefly / sidestep with note / make this the sermon focus]
```

---

## The "preach with awareness" rule

The preacher should think before preaching about:

1. **Who in the room will be affected?** Sexual abuse survivors hearing a sermon on submission; divorced hearers on marriage; the recently bereaved on God's goodness.
2. **What objection will the smart non-Christian have?** "But the OT herem warfare is genocide" — better to acknowledge and explain than to be ambushed in conversation later.
3. **Where might my own tribe's reading be too quick?** Reformed preachers can miss the conditional warnings; non-Cessationists can miss the historical particularity of Acts events.
4. **What pastoral note should accompany the exegetical point?** Acknowledging difficulty doesn't weaken the truth; it serves it.

---

## Pitfall

**Over-flagging** every passage as controversial. The test is whether there are *real* difficulties in this *particular* passage. Most preaching passages have 0–2 issues worth this kind of treatment; some have many.

**Under-flagging** out of fear or laziness. A preacher who hits 1 Tim 2 or Joshua 6 without having thought through the difficulties will preach badly.

**Resolving on Claude's behalf.** This extension's job is to *surface* the issues, not to take positions on contested matters. Show the preacher what they need to think about; let them decide where they land.

**Confusing your own discomfort with the text's difficulty.** Sometimes the passage is fine and the preacher needs to grow up; sometimes the difficulty is real. Be honest about which.

**Oversimplifying to defend against misuse.** When a verse is flagged as commonly weaponised or doctrinally sensitive, there's a pull to make the "safe" reading as clean as possible — which can mean smoothing away real tension the text itself holds, in the opposite direction from the misuse being guarded against. A text that mixes, say, voluntary inclusion with genuine reversal-of-power imagery does not become safer to preach by being flattened into "it's all voluntary" — it becomes less accurate, and a sharp-eyed hearer may notice the gap between the flattened reading and what the text actually says. Guard against the misuse by naming the text's actual range under "What an honest exegesis surfaces," not by erasing the half of it that feels riskier to leave in.
