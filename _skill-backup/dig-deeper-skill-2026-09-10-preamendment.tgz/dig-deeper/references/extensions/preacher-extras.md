# Preacher Extras

Two preacher-specific sections that go at the **top** and **bottom** of the report respectively:

1. **Headline Findings** — at the top, before the tool walkthrough. The 3–5 highest-conviction claims a preacher can trust most.
2. **Preaching Pitfalls** — near the bottom, after the tool walkthrough. Common misreadings of this passage and how to avoid them.

These are written *after* the tool walkthrough is complete, but presented in the report at top and bottom because they're the most preacher-useful sections.

---

## Headline Findings

### What this is

A short list (3–5 bullet points) of the highest-conviction exegetical claims that emerged from the tool walkthrough. These are the points a preacher should *trust most* and *probably make somewhere* in the sermon.

### Criteria for inclusion

A finding earns a place in Headline Findings if it meets **all** of:

- It emerged from **multiple tools converging** (not from a single tool alone)
- It is **high-confidence** (not flagged as moderate or uncertain)
- It is **central to the passage**, not peripheral
- It would be **homiletically generative** — i.e., a preacher could naturally build around it

### What this is *not*

- Not a Teaching Point — TPs are crafted in `/point-purpose`; this is raw material
- Not a summary of every finding — only the trustworthy core
- Not Claude's *opinions* — these are observations the text supports strongly

### Structure

```markdown
## Headline Findings

The exegetically strongest claims that emerged across multiple tools:

1. **[Concise claim, ~1 sentence]** — Surfaced by: [tools that converged on this]. [One sentence on why it matters.]
2. **[Concise claim]** — Surfaced by: [tools]. [One sentence.]
3. **[Concise claim]** — Surfaced by: [tools]. [One sentence.]

[3–5 bullets total. If only 2 strong findings emerged, that's fine — better to be brief and trustworthy than to pad.]
```

### Example (Psalm 33:1–9, see examples/psalm-33-worked.md)

> 1. **God's word as effective creative agent is the centre of the passage.** Surfaced by: Repetition (vv.4, 6, 9), Linking Words (the two "for"s grounding worship in God's word), Parallels (word=work; word=breath/Spirit), Quotation/Allusion (Gen 1 explicit). This is the strongest convergence in the passage.
> 2. **Universal scope of the worship summons.** Surfaced by: Repetition ("all" five times), Structure (the second imperative widens from "the righteous" to "all the earth"), So-What (the four-audience question — this passage already addresses all four).
> 3. **The fitting response is praise/fear/awe — not bare duty.** Surfaced by: Author's Purpose, Tone and Feel, Vocabulary (fear = awe). Worship here is the natural response to *who God is*, not a moral demand.

---

## Preaching Pitfalls

### What this is

Common misreadings or mishandlings of *this specific passage* that the preacher should be aware of before stepping into the pulpit.

### Sources of pitfalls

A pitfall earns a place if it's one of:

| Source | Examples |
|--------|----------|
| **Popular misuse of the passage** | Jer 29:11 ("plans to prosper"); Phil 4:13 in athletic contexts |
| **Translation-driven errors** | NIV smoothing "therefore" → "yet" in John 11:6 |
| **Genre confusion** | Reading parables as history; apocalyptic as documentary |
| **Copycat errors** | Treating descriptive narrative as prescriptive |
| **"Moses-is-me" errors** | Self-inserting where Christ is the type |
| **Bible-timeline errors** | Applying OT promises without filtering through Christ |
| **Pulling from context** | Reading verses without surrounding flow |
| **Moralistic OT preaching** | "Be like David / Daniel / Esther" without Christ |
| **Theological-tribe blind spots** | A Calvinist will read X this way; an Arminian that way — what does the passage actually say? |
| **Pastoral landmines** | Where the application will land badly on certain hearers without care |
| **Standard sermon clichés** | The sermon "everyone preaches" that misses what's actually here |

### What this is *not*

- Not a list of *all* possible misreadings (that's infinite)
- Not theological tribal warfare
- Not personal opinions on contested matters where the passage genuinely allows multiple readings

### Structure

```markdown
## Preaching Pitfalls

Common ways this passage gets mishandled, and how to avoid them:

### Pitfall: [Brief description]

- **What it looks like:** [How the misreading sounds in a sermon]
- **Why it's wrong:** [The exegetical or theological problem]
- **The corrective:** [What the passage actually does / says]

[Repeat for 2–5 pitfalls — most passages have a handful worth flagging]
```

### Example (a passage like John 14:1–6)

> ### Pitfall: "In my Father's house are many rooms" as a sentimental funeral text divorced from context
>
> - **What it looks like:** "Jesus has prepared a special room just for your loved one in heaven"
> - **Why it's wrong:** The "many rooms / mansions" language is about Christ's preparing the way through his death, resurrection, and ascension — and about the disciples' confidence as he goes ahead. It's not architecturally about heaven's real-estate.
> - **The corrective:** Preach this in the context of Christ's departure, the disciples' troubled hearts, and the assurance that comes from Christ as "the way".
>
> ### Pitfall: "I am the way, the truth, and the life" applied as bare proposition stripped from Christ's high-priestly going-ahead
>
> - **What it looks like:** A philosophical apologetic for Christ's uniqueness divorced from the narrative flow
> - **Why it's wrong:** The verse is uttered in answer to Thomas's "we don't know the way" — the way *to where the Father is*, *to the Father himself*. It's not primarily an apologetic claim against other religions (though it does have that implication); it's a pastoral promise to troubled disciples.
> - **The corrective:** Anchor the famous statement in Thomas's question and the broader chapter's pastoral purpose.

---

## How to generate Headline Findings and Preaching Pitfalls

**Headline Findings** — generate by reviewing the completed tool walkthrough and asking:
- Which findings appeared under multiple tools?
- Which were marked *high confidence*?
- Which sit at the heart of the passage rather than its periphery?
- Which would a preacher naturally build around?

**Preaching Pitfalls** — generate by asking:
- Is this passage commonly misused or pulled from context?
- Are there well-known "sermon clichés" for this passage that miss its actual point?
- Does the passage contain a difficult / contested issue (see difficult-verses.md)?
- Does the passage tempt to moralism, Moses-is-me, or copycat error?
- Are there translation issues that have led to widespread misreading?
- Are there pastoral landmines (see difficult-verses.md)?

---

## Operational guidance

- **Headline Findings** goes at the **top** of the report (after the passage quote, before the tool walkthrough). The preacher should be able to skim this and get the trustworthy core in 30 seconds.
- **Preaching Pitfalls** goes near the **bottom** of the report (after the tool walkthrough, after Convergent Findings, before Open Questions).
- Both sections should be *brief but rich*. Don't pad. Don't claim more than the evidence supports.

---

## Pitfall (of this extension)

**Headline Findings that aren't really headline.** If a "finding" rests on a single tool or moderate-confidence claim, it doesn't belong here — leave it in the tool walkthrough.

**Preaching Pitfalls as personal disagreement with how others preach.** The criteria is *misreading the passage*, not *not preaching it your way*.

**Generating these before the tool walkthrough is done.** They need to flow from the evidence. Do them last.
