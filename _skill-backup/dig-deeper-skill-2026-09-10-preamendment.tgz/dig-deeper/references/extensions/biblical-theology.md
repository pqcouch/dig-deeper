# Extension: Biblical Theology

The Quotation/Allusion tool catches the **echoes** in a passage. This extension asks the bigger question: **what theme(s) does this passage participate in across the canon, and how does the canon's whole development reframe what we read here?**

Biblical theology = reading the Bible as a single unfolding story with developing themes. Goldsworthy, Vos, Beale, Carson, Roberts.

---

## When to use this extension

Use whenever a passage participates in a **major biblical-theological theme** — which is most passages. The selection question is: *which 1–3 themes most illuminate this passage?*

Skip only if:
- The passage is wholly self-contained (rare)
- The book-overview's intertextual map has already done this work comprehensively at the passage level

---

## Major biblical-theological themes

Each theme below has a typical canonical trajectory. When a passage participates in one, trace where it sits and where the theme is going.

### Kingdom of God

| Stage | Markers |
|-------|---------|
| **Creation** | God's rule over creation; Adam as vice-regent (Gen 1:26–28) |
| **Fall** | Rebellion; serpent's counter-kingdom |
| **Patriarchs** | Promise of a great nation (Gen 12); kings will come from Abraham (Gen 17:6) |
| **Exodus / Sinai** | YHWH as King; "kingdom of priests" (Exod 19:6) |
| **Judges** | Failed pattern: "no king in Israel" |
| **Monarchy** | Davidic covenant (2 Sam 7); kingdom forever |
| **Divided / Exile** | Failed kingship; prophetic hope of restored kingdom |
| **NT inauguration** | "Kingdom of God has come near" (Mark 1:15); Jesus as king |
| **Already / not-yet** | Kingdom present in Christ's reign, future in consummation |
| **Consummation** | "The kingdom of the world has become the kingdom of our Lord" (Rev 11:15) |

### Covenant

| Stage | Covenant |
|-------|----------|
| **Noahic** | Preservation of creation order (Gen 9) |
| **Abrahamic** | Land, seed, blessing (Gen 12, 15, 17) |
| **Mosaic** | Conditional national covenant (Exod 19–24) |
| **Davidic** | Royal house forever (2 Sam 7) |
| **New** | Promised in Jer 31; inaugurated in Christ's blood (Luke 22; Heb 8) |

### Temple / God's presence

| Stage | Form |
|-------|------|
| **Eden** | Garden as proto-temple; God walks with humanity |
| **Patriarchs** | Local theophanies, altars |
| **Tabernacle** | Portable dwelling among Israel (Exod 25–40) |
| **Solomonic temple** | Settled dwelling in Jerusalem (1 Kings 6–8) |
| **Departure of glory** | God's glory leaves the temple (Ezek 10) |
| **Second temple** | Rebuilt, but without the glory cloud (cf. Ezra 3) |
| **Christ as temple** | "Destroy this temple..." (John 2); "the Word tabernacled" (John 1:14) |
| **Church as temple** | Spirit indwells believers (1 Cor 3:16; Eph 2:21) |
| **New creation** | "No temple in the city, for its temple is the Lord God Almighty and the Lamb" (Rev 21:22) |

### Image of God / new humanity

| Stage | Form |
|-------|------|
| **Creation** | Humanity made in God's image (Gen 1:26–27) |
| **Fall** | Image marred but not erased |
| **Promised seed** | The line through which restoration comes |
| **Israel as son** | Corporate image-bearer (Exod 4:22) |
| **Christ as image** | True image of God (Col 1:15; Heb 1:3) |
| **Believers conformed** | Renewed to Christ's image (Rom 8:29; 2 Cor 3:18) |
| **Consummation** | Bear the image of the heavenly man (1 Cor 15:49) |

### Land / rest / inheritance

| Stage | Form |
|-------|------|
| **Eden** | Original "land" — garden of God |
| **Promise to Abraham** | Specific land of Canaan |
| **Conquest** | Canaan inhabited; rest given (Josh 21:44) |
| **Sabbath rest** | Pattern of cessation (Gen 2; Exod 20) |
| **Davidic peace** | Rest from enemies (2 Sam 7:11) |
| **Exile** | Loss of land — rest forfeited |
| **Return** | Partial reclamation |
| **NT reframing** | "He has set another day" (Heb 4:8); the heavenly country (Heb 11:16) |
| **Consummation** | Inheritance fully entered (Rev 21–22) |

### Exodus / new exodus

| Stage | Form |
|-------|------|
| **Egypt to Sinai** | The paradigm rescue |
| **Prophetic anticipation** | Isaiah esp.: new exodus from exile (Isa 40, 43, 52) |
| **Christ's exodus** | "His departure [*exodos*] at Jerusalem" (Luke 9:31); cross as exodus |
| **Christian life** | We have been brought through the water (1 Cor 10), are in wilderness, awaiting the land |
| **Consummation** | The Lamb's victory song (Rev 15) echoes Moses' song |

### Sacrifice / atonement

| Stage | Form |
|-------|------|
| **Eden** | First sacrifice — God clothes Adam and Eve (Gen 3:21) |
| **Cain and Abel** | Sacrifices distinguished |
| **Patriarchs** | Altars, burnt offerings |
| **Mosaic** | Tabernacle system; Day of Atonement (Lev 16) |
| **Substitution typology** | Passover lamb; scapegoat |
| **Prophetic critique** | "I desire mercy, not sacrifice" (Hos 6:6) — not abolishing but contextualising |
| **Christ's sacrifice** | "Once for all" (Heb 9:26); the fulfilment |
| **Christian response** | "Living sacrifices" (Rom 12:1) |
| **Consummation** | No more sacrifice needed |

### Marriage / divine-human union

| Stage | Form |
|-------|------|
| **Eden** | Marriage instituted; "one flesh" (Gen 2) |
| **Hosea / Ezekiel** | God's covenant marriage to Israel; spiritual adultery |
| **Song of Songs** | Marriage as theological category |
| **Christ as bridegroom** | John 3:29; Matt 9:15 |
| **Church as bride** | Eph 5:22–33 |
| **Consummation** | Marriage supper of the Lamb (Rev 19:7–9; 21:2) |

### Shepherd / king

| Stage | Form |
|-------|------|
| **Patriarchs as shepherds** | Abraham, Isaac, Jacob, Moses, David |
| **YHWH as shepherd** | Ps 23; "the LORD is my shepherd" |
| **Failed shepherds** | Ezek 34: condemnation of Israel's leaders |
| **Promised shepherd-king** | Ezek 34:23; Mic 5:4 |
| **Christ as good shepherd** | John 10; "I am the good shepherd" |
| **Under-shepherds** | 1 Pet 5:2–4; pastoral leadership |
| **Consummation** | The Lamb shepherds them (Rev 7:17) |

### Word of God

| Stage | Form |
|-------|------|
| **Creation** | "Let there be" — creation by word |
| **Patriarchs** | Word of God comes to Abraham, the prophets |
| **Sinai** | Words spoken and written |
| **Prophetic** | "The word of the LORD came to..." |
| **Wisdom** | Word personified (Prov 8) |
| **Christ as Word** | John 1:1 — the Word made flesh |
| **Apostolic** | Spirit-given testimony; written down |
| **Church** | "Faith comes by hearing" |
| **Consummation** | "His name is The Word of God" (Rev 19:13) |

### Spirit

| Stage | Form |
|-------|------|
| **Creation** | Spirit hovering over the waters (Gen 1:2) |
| **Empowerment of select individuals** | Bezalel, judges, kings, prophets |
| **Promised outpouring** | Ezek 36, Joel 2 |
| **Christ's anointing** | At baptism; "without measure" (John 3:34) |
| **Pentecost** | Promise fulfilled (Acts 2) |
| **Indwelling of all believers** | Rom 8; Eph 1:13–14 |
| **Eschatological fullness** | Glorification |

### Wisdom

| Stage | Form |
|-------|------|
| **Eden** | True wisdom = fear of the Lord vs deception |
| **Solomon** | Pinnacle of human wisdom |
| **Personified wisdom** | Proverbs 8 |
| **Vanity** | Ecclesiastes — wisdom's limits without God |
| **Christ as wisdom** | "Greater than Solomon" (Matt 12:42); "Christ the wisdom of God" (1 Cor 1:24, 30) |

### Adversary / sin / death / new creation

| Stage | Form |
|-------|------|
| **Eden** | The Serpent introduces rebellion and death (Gen 3); God promises enmity between the seed of the woman and the seed of the serpent — the *proto-evangelium* (Gen 3:15) |
| **Sin's dominion** | Death reigns as the consequence of sin from Adam onward (Gen 3:19; Rom 5:12–14); the adversarial power introduced at the fall pervades the OT narrative |
| **Satan as named figure** | The adversary appears explicitly (Job 1–2; 1 Chron 21:1; Zech 3:1–2); tests, accuses, opposes — but operates within God's sovereignty |
| **Prophetic anticipation** | Death will be swallowed up (Isa 25:8); the Servant bears sin and death on behalf of others (Isa 53:5–6, 12); creation will be renewed (Isa 65:17; Ezek 37) |
| **Christ's victory** | The cross as the event answering Genesis 3 — Christ bears the death sin earned (Gal 3:13; 2 Cor 5:21), destroys the one who holds the power of death (Heb 2:14–15), disarms the powers (Col 2:15); the resurrection as the defeat of death itself (1 Cor 15:21–22, 54–57) |
| **Already / not-yet** | Death defeated but not yet abolished (1 Cor 15:26); Satan's power broken but not yet destroyed (Rev 20:2–3, 10) |
| **Consummation** | Death thrown into the lake of fire (Rev 20:14); no more death, mourning, crying, or pain (Rev 21:4); creation renewed (Rev 21–22) |

**Special case — when an adversarial figure (Satan, the serpent, demonic forces) appears in a passage:** don't limit the analysis to the immediate context. Trace the figure back to its canonical origin and ask: is this passage depicting a *reversal* of what the Adversary accomplished in Genesis 3, a *perpetuation* of it, or a *foretaste* of final defeat? Passages involving Jesus confronting Satan (Mark 1:12-13; 8:33; Luke 10:18) often carry this cosmic frame: the question is not only "what does this tell us about Jesus?" but "where does this sit in the long story of sin, death, and defeat?" The Genesis 3 frame frequently unlocks the cosmic dimension of passages that might otherwise appear to be purely ethical or Christological.

---

## Operational guidance for the report

Select **1–3 themes** that most illuminate the passage (not all of them). For each:

```markdown
## Biblical-Theological Themes

### [Theme name]

- **Where this passage sits in the trajectory:** [stage]
- **What comes before in the canonical development:** [briefly — key earlier moments the passage assumes or echoes]
- **What comes after:** [where the theme goes; especially Christ-fulfilment for OT passages]
- **What this contributes to the passage's meaning:** [the payoff — why tracing the theme matters here]
- **Confidence:** *high / moderate / uncertain*

[Repeat for 1–2 more themes if applicable]
```

**Be selective.** A passage on God's faithfulness might touch 5 themes — but only 1–2 will materially shape how it should be preached. Choose by these criteria, in order:

1. **Textual signal:** the passage's own vocabulary, structure, or allusions invoke the theme (the strongest claim to inclusion — a theme the text names beats a theme the canon makes available).
2. **Purpose connection:** the theme serves the passage's main point (Tool 1, Author's Purpose), not a side detail. A theme attached to an incidental phrase fails this test however major the theme is canonically.
3. **Trajectory payoff:** tracing the theme *changes* how the passage would be preached — it supplies something a theme-blind reading would miss (a Christ-connection, a corrective to a misreading, the reason a detail is present).

A theme that passes 1 but fails 2 and 3 gets a one-line mention at most. A theme that fails 1 should not appear unless 2 and 3 are both strong — and then flag it as canonical-reflection, not textual claim.

**Watch for confluence.** When two or more *selected* themes converge, state explicitly **how** they relate — a list of separate themes is a catalogue, not an analysis. Three relations to choose between:

- **(a) Parallel:** the themes run side by side toward the same fulfilment without depending on each other.
- **(b) Mutual illumination:** one theme explains why the other appears here (e.g. exodus language appearing because the kingdom theme needs a rescue-shaped king).
- **(c) Climactic convergence:** the themes meet in a single reality the passage names — this is usually where the preaching gold is. Hebrews 4 doesn't just *touch* rest, land, sabbath, and priesthood; it argues that the rest the land never delivered is entered through the priest.

Name the relation in the report; if you can't say which it is, you haven't finished the confluence work.

**Hand-off:** If the book-overview has an intertextual map, use it; complement it with passage-level theme tracing.

---

## Pitfall

Tracing themes the passage doesn't actually participate in. Forcing a theme just because it's a major one. Stretching minor verbal echoes into theme-participation. Theme-tracing should make the passage *more* itself, not less.

Also: don't confuse biblical theology with systematic theology. Biblical theology asks *where in the story*; systematic theology asks *what is always true*. Both matter, but this extension is the former.
